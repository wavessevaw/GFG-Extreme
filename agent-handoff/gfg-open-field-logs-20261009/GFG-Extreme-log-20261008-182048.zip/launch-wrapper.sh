#!/bin/bash
# mako-wrapper-format: 83
# governor diagnostics: enabled only by runtime marker
# Current profile: mako
# mako-host-compatibility: aarch64-passthrough-v1
mako_native_arch="$(uname -m 2>/dev/null || true)"
if [ -f "/usr/libexec/armada/device-env" ] || [ "$mako_native_arch" = "aarch64" ] || [ "$mako_native_arch" = "arm64" ]; then
    # This release has no validated native AArch64 Renderer.
    unset ENABLE_MAKO
    export DISABLE_MAKO=1
    armada_game_launch="/usr/libexec/armada/armada-game-launch"
    if [ -f "/usr/libexec/armada/device-env" ] && [ -x "$armada_game_launch" ]; then
        for argument in "$@"; do
            if [ "$argument" = "$armada_game_launch" ]; then
                exec "$@"
            fi
        done
        exec "$armada_game_launch" "$@"
    fi
    exec "$@"
fi
mako_wrapper_profile="${MAKO_PROFILE:-}"
mako_wrapper_profile_from_identity=0
mako_wrapper_app_id="${SteamAppId:-${SteamGameId:-${STEAM_COMPAT_APP_ID:-}}}"
if [ -z "$mako_wrapper_profile" ]; then
    if [ -n "$mako_wrapper_app_id" ]; then
        case "$mako_wrapper_app_id" in
            *)
                mako_wrapper_profile=mako
                ;;
        esac
    else
        case " $* " in
            *)
                mako_wrapper_profile=mako
                ;;
        esac
    fi
fi
case "$mako_wrapper_profile" in
    mako)
        export MAKO_DISABLE_HDR_EXPOSURE=1
        export MAKO_EXTERNAL_VULKAN_LAYER=vkbasalt
        mako_gamescope_wsi_required=0
        mako_renderer_required=1
        mako_spatial_scaling_required=0
        unset DXVK_HDR
        gfg_manifest_path=/home/deck/.config/mako-render/runtime-state/launches/6e2e6e988e756da9.json
        gfg_manifest_saved_backend=gfg
        gfg_manifest_saved_fg=true
        gfg_manifest_saved_dock=false
        gfg_manifest_effective_fg=true
        gfg_manifest_effective_dock=false
        gfg_manifest_scaling=true
        gfg_manifest_shaders=true
        gfg_manifest_renderer_required=true
        gfg_manifest_proxy=auto
        gfg_manifest_target_fps=90
        mako_governor_overlay=/home/deck/.config/mako-render/governor-overlay/overlay-6e2e6e988e756da9.toml
        mako_vkbasalt_config=/home/deck/.config/vkBasalt/vkBasalt.conf
        ;;
    *)
        export MAKO_DISABLE_HDR_EXPOSURE=1
        export MAKO_EXTERNAL_VULKAN_LAYER=vkbasalt
        mako_gamescope_wsi_required=0
        mako_renderer_required=1
        mako_spatial_scaling_required=0
        unset DXVK_HDR
        gfg_manifest_path=/home/deck/.config/mako-render/runtime-state/launches/6e2e6e988e756da9.json
        gfg_manifest_saved_backend=gfg
        gfg_manifest_saved_fg=true
        gfg_manifest_saved_dock=false
        gfg_manifest_effective_fg=true
        gfg_manifest_effective_dock=false
        gfg_manifest_scaling=true
        gfg_manifest_shaders=true
        gfg_manifest_renderer_required=true
        gfg_manifest_proxy=auto
        gfg_manifest_target_fps=90
        mako_governor_overlay=/home/deck/.config/mako-render/governor-overlay/overlay-6e2e6e988e756da9.toml
        mako_vkbasalt_config=/home/deck/.config/vkBasalt/vkBasalt.conf
        ;;
esac
if [ "$mako_wrapper_profile_from_identity" = "1" ]; then
    export MAKO_PROFILE="$mako_wrapper_profile"
fi
export MAKO_PRESENT_ACQUIRE_TIMEOUT_MS="${MAKO_PRESENT_ACQUIRE_TIMEOUT_MS:-50}"
mako_governor_diagnostics_marker=/home/deck/.config/mako-render/runtime-state/governor-diagnostics.enabled
if [ -f "$mako_governor_diagnostics_marker" ]; then export MAKO_PRESENT_DIAGNOSTICS="${MAKO_PRESENT_DIAGNOSTICS:-1}"; else export MAKO_PRESENT_DIAGNOSTICS="${MAKO_PRESENT_DIAGNOSTICS:-0}"; fi
unset mako_governor_diagnostics_marker
gfg_frame_os_marker=/home/deck/.config/mako-render/runtime-state/frame-os.enabled
gfg_frame_os=0
if [ -f "$gfg_frame_os_marker" ] && [ -r /home/deck/.local/share/mako-render/vulkan/gfg-frame-os/VkLayer_gfg_pacer.json ]; then
    gfg_frame_os=1
    export GFG_FRAME_OS_SHM="${GFG_FRAME_OS_SHM:-/dev/shm/gfg-frame-os}"
fi
unset GFG_FRAME_OS
unset GFG_FRAME_OS_ENABLE GFG_FRAME_OS_MODE GFG_FRAME_OS_REAL_HZ GFG_FRAME_OS_TICK_SHAPING GFG_FRAME_OS_PACING
export DISABLE_GFG_FRAME_OS=1
unset gfg_frame_os_marker
gfg_hud_marker=/home/deck/.config/mako-render/runtime-state/hud-rings.enabled
gfg_hud=0
if [ -f "$gfg_hud_marker" ] && [ -r /home/deck/.local/share/mako-render/vulkan/gfg-frame-os/VkLayer_gfg_hud.json ]; then
    gfg_hud=1
    export GFG_HUD_FILE="${GFG_HUD_FILE:-/dev/shm/gfg-hud.raw}"
    export GFG_HUD_EXTENT_FILE="${GFG_HUD_EXTENT_FILE:-/dev/shm/gfg-hud.extent}"
fi
unset GFG_HUD
export DISABLE_GFG_HUD=1
unset gfg_hud_marker
mako_renderer_enabled=0
if [ "${mako_renderer_required:-0}" = 1 ] && [ "${DISABLE_MAKO:-0}" != 1 ]; then
    unset DISABLE_MAKO
    export ENABLE_MAKO=1
    mako_renderer_enabled=1
else
    unset ENABLE_MAKO
    export DISABLE_MAKO=1
fi
unset MAKO_SPLIT_LAYER_CHAIN
export DISABLE_LSFG=1
export DISABLE_LSFGVK=1
export DISABLE_GAMESCOPE_WSI=1
unset ENABLE_GAMESCOPE_WSI
export DISABLE_MAKO_SPATIAL_SCALING=1
unset ENABLE_MAKO_SPATIAL_SCALING
mako_existing_instance_layers=":${VK_INSTANCE_LAYERS:-}:"
while [[ "$mako_existing_instance_layers" == *":VK_LAYER_MAKO_render:"* ]]; do
    mako_existing_instance_layers="${mako_existing_instance_layers/:VK_LAYER_MAKO_render:/:}"
done
while [[ "$mako_existing_instance_layers" == *":VK_LAYER_MAKO_spatial_scaling:"* ]]; do
    mako_existing_instance_layers="${mako_existing_instance_layers/:VK_LAYER_MAKO_spatial_scaling:/:}"
done
while [[ "$mako_existing_instance_layers" == *":VK_LAYER_FROG_gamescope_wsi_x86_64:"* ]]; do
    mako_existing_instance_layers="${mako_existing_instance_layers/:VK_LAYER_FROG_gamescope_wsi_x86_64:/:}"
done
while [[ "$mako_existing_instance_layers" == *":VK_LAYER_VKBASALT_post_processing:"* ]]; do
    mako_existing_instance_layers="${mako_existing_instance_layers/:VK_LAYER_VKBASALT_post_processing:/:}"
done
while [[ "$mako_existing_instance_layers" == *":VK_LAYER_MAKO_EXTREME_predictive:"* ]]; do
    mako_existing_instance_layers="${mako_existing_instance_layers/:VK_LAYER_MAKO_EXTREME_predictive:/:}"
done
while [[ "$mako_existing_instance_layers" == *":VK_LAYER_GFG_pacer:"* ]]; do
    mako_existing_instance_layers="${mako_existing_instance_layers/:VK_LAYER_GFG_pacer:/:}"
done
while [[ "$mako_existing_instance_layers" == *":VK_LAYER_GFG_hud:"* ]]; do
    mako_existing_instance_layers="${mako_existing_instance_layers/:VK_LAYER_GFG_hud:/:}"
done
mako_existing_instance_layers="${mako_existing_instance_layers#:}"
mako_existing_instance_layers="${mako_existing_instance_layers%:}"
if [ -n "$mako_existing_instance_layers" ]; then
    export VK_INSTANCE_LAYERS="$mako_existing_instance_layers"
else
    unset VK_INSTANCE_LAYERS
fi
mako_managed_instance_layers=
mako_managed_external_layer=
mako_steam_overlay_layers=
mako_gamescope_wsi_session=0
mako_gamescope_wsi_skip_log=
if [ -n "${GAMESCOPE_WAYLAND_DISPLAY:-}" ] && { [ -z "${WAYLAND_DISPLAY:-}" ] || [ "${WAYLAND_DISPLAY}" = "${GAMESCOPE_WAYLAND_DISPLAY}" ]; }; then
    mako_gamescope_wsi_session=1
fi
mako_external_vulkan_layer="${MAKO_EXTERNAL_VULKAN_LAYER:-}"
unset MAKO_EXTERNAL_VULKAN_LAYER
mako_gamescope_wsi_layer_dir=/home/deck/.local/share/mako-render/vulkan/gamescope_wsi_compatibility.d
mako_spatial_scaling_layer_dir=/home/deck/.local/share/mako-render/vulkan/spatial_scaling.d
mako_mangohud_layer_dir=/home/deck/.local/share/mako-render/vulkan/mangohud.d
mako_vkbasalt_layer_dir=/home/deck/.local/share/mako-render/vulkan/vkbasalt.d
mako_vkbasalt_enabled=0
mako_flatpak_runtime=0
mako_flatpak_launch=0
if [ "${1##*/}" = flatpak ] && [ "${2:-}" = run ]; then
    mako_flatpak_launch=1
fi
unset MANGOHUD
unset VKBASALT_CONFIG_FILE
unset VKBASALT_CONFIG_RELOAD
export DISABLE_VKBASALT=1
unset ENABLE_VKBASALT
if [ -d /usr/lib/extensions/vulkan/makorender/share/vulkan/implicit_layer.d ] || [ "$mako_flatpak_launch" = 1 ]; then
    mako_implicit_layer_path=/usr/lib/extensions/vulkan/makorender/share/vulkan/implicit_layer.d
    mako_flatpak_runtime=1
    mako_spatial_scaling_manifest="$mako_implicit_layer_path/VkLayer_MAKO_spatial_scaling.json"
    mako_vkbasalt_manifest="$mako_implicit_layer_path/vkBasalt.json"
    mako_vkbasalt_manifest32="$mako_implicit_layer_path/vkBasalt.x86.json"
    mako_vkbasalt_layer_dir="$mako_implicit_layer_path"
else
    mako_implicit_layer_path=/home/deck/.local/share/mako-render/vulkan/implicit_layer.d
    mako_spatial_scaling_manifest=/home/deck/.local/share/mako-render/vulkan/spatial_scaling.d/VkLayer_MAKO_spatial_scaling.json
    mako_vkbasalt_manifest=/home/deck/.local/share/mako-render/vulkan/vkbasalt.d/vkBasalt.json
    mako_vkbasalt_manifest32=/home/deck/.local/share/mako-render/vulkan/vkbasalt.d/vkBasalt.x86.json
fi
if [ "$mako_renderer_enabled" = 1 ] && [ "${mako_gamescope_wsi_required:-0}" = 1 ] && [ "$mako_gamescope_wsi_session" = 1 ] && [ -r /home/deck/.local/share/mako-render/vulkan/gamescope_wsi_compatibility.d/VkLayer_FROG_gamescope_wsi.x86_64.json ] && ( [ "${mako_spatial_scaling_required:-0}" != 1 ] || [ -r "$mako_spatial_scaling_manifest" ] || [ "$mako_flatpak_launch" = 1 ] ) && [ "${DISABLE_MAKO:-0}" != 1 ]; then
    if [ "${mako_spatial_scaling_required:-0}" = 1 ]; then
        export MAKO_SPLIT_LAYER_CHAIN=2
    fi
    unset DISABLE_GAMESCOPE_WSI
    export ENABLE_GAMESCOPE_WSI=1
    export NODEVICE_SELECT=1
    export DISABLE_LAYER_MESA_ANTI_LAG=1
    mako_managed_instance_layers=VK_LAYER_MAKO_render:VK_LAYER_FROG_gamescope_wsi_x86_64
    mako_implicit_layer_path="$mako_implicit_layer_path:$mako_gamescope_wsi_layer_dir"
    if [ "${mako_spatial_scaling_required:-0}" = 1 ]; then
        unset DISABLE_MAKO_SPATIAL_SCALING
        export ENABLE_MAKO_SPATIAL_SCALING=1
        mako_managed_instance_layers="$mako_managed_instance_layers:VK_LAYER_MAKO_spatial_scaling"
        if [ "$mako_flatpak_runtime" != 1 ]; then
            mako_implicit_layer_path="$mako_implicit_layer_path:$mako_spatial_scaling_layer_dir"
        fi
    fi
elif [ "$mako_renderer_enabled" = 1 ] && [ "${mako_gamescope_wsi_required:-0}" = 1 ] && [ "$mako_gamescope_wsi_session" != 1 ]; then
    mako_gamescope_wsi_skip_log="GFG Extreme: Gamescope WSI skipped: no active Gamescope session; continuing with the managed WSI and spatial chain disabled."
fi
mako_governor_hud=0
if [ -r /home/deck/.config/mako-render/hud/active.conf ]; then
    if [ -z "$mako_external_vulkan_layer" ]; then
        mako_external_vulkan_layer=mangohud
        export MANGOHUD_CONFIGFILE=/home/deck/.config/mako-render/hud/active.conf
    elif [ "$mako_external_vulkan_layer" = vkbasalt ]; then
        mako_governor_hud=1
        export MANGOHUD_CONFIGFILE=/home/deck/.config/mako-render/hud/active.conf
    fi
fi
case "$mako_external_vulkan_layer" in
        mangohud)
            if [ "$mako_flatpak_runtime" != 1 ] && { [ -r /home/deck/.local/share/mako-render/vulkan/mangohud.d/MangoHud.x86_64.json ] || [ -r /home/deck/.local/share/mako-render/vulkan/mangohud.d/MangoHud.x86.json ]; }; then
                unset DISABLE_MANGOHUD
                export MANGOHUD=1
                export NODEVICE_SELECT=1
                export DISABLE_LAYER_MESA_ANTI_LAG=1
                mako_implicit_layer_path="$mako_implicit_layer_path:$mako_mangohud_layer_dir"
                if [ -r /home/deck/.local/share/mako-render/vulkan/mangohud.d/MangoHud.x86_64.json ]; then
                    mako_managed_external_layer=VK_LAYER_MANGOHUD_overlay_x86_64
                fi
            fi
            ;;
        vkbasalt)
            if { [ -z "$mako_vkbasalt_config" ] || [ -r "$mako_vkbasalt_config" ]; } && { [ -r "$mako_vkbasalt_manifest" ] || [ -r "$mako_vkbasalt_manifest32" ] || [ "$mako_flatpak_launch" = 1 ]; }; then
                if [ -n "$mako_vkbasalt_config" ]; then
                    export VKBASALT_CONFIG_FILE="$mako_vkbasalt_config"
                    export VKBASALT_CONFIG_RELOAD=1
                fi
                unset DISABLE_VKBASALT
                export ENABLE_VKBASALT=1
                mako_vkbasalt_enabled=1
                export NODEVICE_SELECT=1
                export DISABLE_LAYER_MESA_ANTI_LAG=1
                if [ "$mako_flatpak_runtime" != 1 ]; then
                    mako_implicit_layer_path="$mako_implicit_layer_path:$mako_vkbasalt_layer_dir"
                fi
                if [ -r "$mako_vkbasalt_manifest" ] || [ "$mako_flatpak_launch" = 1 ]; then
                    mako_managed_external_layer=VK_LAYER_VKBASALT_post_processing
                fi
            fi
            ;;
esac
if [ "$mako_governor_hud" = 1 ] && [ "$mako_flatpak_runtime" != 1 ] && { [ -r /home/deck/.local/share/mako-render/vulkan/mangohud.d/MangoHud.x86_64.json ] || [ -r /home/deck/.local/share/mako-render/vulkan/mangohud.d/MangoHud.x86.json ]; }; then
    unset DISABLE_MANGOHUD
    export MANGOHUD=1
    export NODEVICE_SELECT=1
    export DISABLE_LAYER_MESA_ANTI_LAG=1
    mako_implicit_layer_path="$mako_implicit_layer_path:$mako_mangohud_layer_dir"
    if [ -r /home/deck/.local/share/mako-render/vulkan/mangohud.d/MangoHud.x86_64.json ]; then
        mako_managed_external_layer="${mako_managed_external_layer:+$mako_managed_external_layer:}VK_LAYER_MANGOHUD_overlay_x86_64"
    fi
elif [ "$mako_governor_hud" = 1 ]; then
    unset MANGOHUD_CONFIGFILE
fi
unset mako_governor_hud
if [ "${ENABLE_VK_LAYER_VALVE_steam_overlay_1:-0}" = 1 ] && [ "$mako_gamescope_wsi_session" != 1 ] && [ "$mako_flatpak_runtime" != 1 ] && { [ -r /home/deck/.local/share/vulkan/implicit_layer.d/steamoverlay_x86_64.json ] || [ -r /home/deck/.local/share/vulkan/implicit_layer.d/steamoverlay_i386.json ]; }; then
    if [ -r /home/deck/.local/share/vulkan/implicit_layer.d/steamoverlay_x86_64.json ]; then
        mako_steam_overlay_layers=VK_LAYER_VALVE_steam_overlay_64
    fi
    if [ -r /home/deck/.local/share/vulkan/implicit_layer.d/steamoverlay_i386.json ]; then
        mako_steam_overlay_layers="${mako_steam_overlay_layers:+$mako_steam_overlay_layers:}VK_LAYER_VALVE_steam_overlay_32"
    fi
    mako_steam_overlay_layer_dir=/home/deck/.local/share/vulkan/implicit_layer.d
    export VK_LAYER_PATH="$mako_steam_overlay_layer_dir${VK_LAYER_PATH:+:$VK_LAYER_PATH}"
    for mako_steam_overlay_layer in VK_LAYER_VALVE_steam_overlay_64 VK_LAYER_VALVE_steam_overlay_32; do
        mako_existing_instance_layers=":$mako_existing_instance_layers:"
        while [[ "$mako_existing_instance_layers" == *":$mako_steam_overlay_layer:"* ]]; do
            mako_existing_instance_layers="${mako_existing_instance_layers/:$mako_steam_overlay_layer:/:}"
        done
        mako_existing_instance_layers="${mako_existing_instance_layers#:}"
        mako_existing_instance_layers="${mako_existing_instance_layers%:}"
    done
    if [ "$mako_renderer_enabled" = 1 ] && [ -z "$mako_managed_instance_layers" ]; then
        mako_managed_instance_layers=VK_LAYER_MAKO_render
    fi
fi
if [ "$gfg_frame_os" = 1 ] && [ "$mako_flatpak_runtime" != 1 ]; then
    if [ "$mako_renderer_enabled" = 1 ] && [ -z "$mako_managed_instance_layers" ]; then
        mako_managed_instance_layers=VK_LAYER_MAKO_render
    fi
    mako_managed_instance_layers="VK_LAYER_GFG_pacer${mako_managed_instance_layers:+:$mako_managed_instance_layers}"
    mako_implicit_layer_path="$mako_implicit_layer_path:"/home/deck/.local/share/mako-render/vulkan/gfg-frame-os
fi
unset gfg_frame_os
if [ "$gfg_hud" = 1 ] && [ "$mako_flatpak_runtime" != 1 ]; then
    if [ "$mako_renderer_enabled" = 1 ] && [ -z "$mako_managed_instance_layers" ]; then
        mako_managed_instance_layers=VK_LAYER_MAKO_render
    fi
    mako_managed_instance_layers="${mako_managed_instance_layers:+$mako_managed_instance_layers:}VK_LAYER_GFG_hud"
    case ":$mako_implicit_layer_path:" in *":"/home/deck/.local/share/mako-render/vulkan/gfg-frame-os":"*) ;; *) mako_implicit_layer_path="$mako_implicit_layer_path:"/home/deck/.local/share/mako-render/vulkan/gfg-frame-os ;; esac
fi
unset gfg_hud
unset MAKO_EXTREME_PFG
unset DISABLE_MAKO_EXTREME_PFG
if [ -n "$mako_managed_instance_layers" ]; then
    if [ -n "$mako_managed_external_layer" ]; then
        mako_managed_instance_layers="$mako_managed_instance_layers:$mako_managed_external_layer"
    fi
    if [ -n "$mako_steam_overlay_layers" ]; then
        mako_managed_instance_layers="$mako_managed_instance_layers:$mako_steam_overlay_layers"
    fi
    if [ -n "$mako_existing_instance_layers" ]; then
        export VK_INSTANCE_LAYERS="$mako_managed_instance_layers:$mako_existing_instance_layers"
    else
        export VK_INSTANCE_LAYERS="$mako_managed_instance_layers"
    fi
    unset ENABLE_MAKO
    unset ENABLE_GAMESCOPE_WSI
    unset ENABLE_MAKO_SPATIAL_SCALING
    case ":$mako_managed_external_layer:" in
        *":VK_LAYER_MANGOHUD_overlay_x86_64:"*) unset MANGOHUD ;;
    esac
    case ":$mako_managed_external_layer:" in
        *":VK_LAYER_VKBASALT_post_processing:"*) unset ENABLE_VKBASALT ;;
    esac
elif [ -n "$mako_steam_overlay_layers" ]; then
    if [ -n "$mako_existing_instance_layers" ]; then
        export VK_INSTANCE_LAYERS="$mako_steam_overlay_layers:$mako_existing_instance_layers"
    else
        export VK_INSTANCE_LAYERS="$mako_steam_overlay_layers"
    fi
fi
unset mako_gamescope_wsi_required
unset mako_gamescope_wsi_session
unset mako_spatial_scaling_required
unset mako_external_vulkan_layer
unset mako_gamescope_wsi_layer_dir
unset mako_spatial_scaling_layer_dir
unset mako_mangohud_layer_dir
unset mako_vkbasalt_layer_dir
unset mako_steam_overlay_layer_dir
unset mako_steam_overlay_layer
unset mako_steam_overlay_layers
unset mako_existing_instance_layers
unset mako_managed_instance_layers
unset mako_managed_external_layer
unset mako_spatial_scaling_manifest
unset mako_vkbasalt_manifest
unset mako_vkbasalt_manifest32
export VK_IMPLICIT_LAYER_PATH="$mako_implicit_layer_path"
unset VK_ADD_IMPLICIT_LAYER_PATH
export MAKO_CONFIG=/home/deck/.config/mako-render/conf.toml
mako_governor_overlay_active=""
if [ -n "${mako_governor_overlay:-}" ] && [ -r "$mako_governor_overlay" ]; then
    mako_governor_launch="$(sed -n 's/^# gfg-governor-launch: //p' "$mako_governor_overlay" 2>/dev/null | head -n 1)"
    mako_governor_owner="${mako_governor_launch##*owner=}"
    mako_governor_owner="${mako_governor_owner%% *}"
    case "$mako_governor_owner" in ''|*[!0-9]*) mako_governor_owner=0 ;; esac
    if [ "$mako_governor_owner" -gt 0 ] && [ -d "/proc/$mako_governor_owner" ]; then
        export MAKO_CONFIG="$mako_governor_overlay"
        mako_governor_overlay_active="$mako_governor_overlay"
    fi
fi
unset mako_governor_overlay mako_governor_launch mako_governor_owner
if [ "${1##*/}" = flatpak ] && [ "${2:-}" = run ]; then
    mako_flatpak_command="$1"
    shift
    mako_flatpak_subcommand="$1"
    shift
    set -- "$mako_flatpak_command" "$mako_flatpak_subcommand" --env=VK_IMPLICIT_LAYER_PATH="${VK_IMPLICIT_LAYER_PATH}" --env=MAKO_CONFIG="${MAKO_CONFIG}" --unset-env=VK_ADD_IMPLICIT_LAYER_PATH "$@"
    if [ "$mako_renderer_enabled" = 1 ] && [ -z "${VK_INSTANCE_LAYERS:-}" ]; then
        set -- "$mako_flatpak_command" "$mako_flatpak_subcommand" --env=ENABLE_MAKO=1 --unset-env=DISABLE_MAKO "${@:3}"
    elif [ "$mako_renderer_enabled" != 1 ]; then
        set -- "$mako_flatpak_command" "$mako_flatpak_subcommand" --unset-env=ENABLE_MAKO --env=DISABLE_MAKO=1 "${@:3}"
    fi
    if [ -n "${VK_INSTANCE_LAYERS:-}" ]; then
        set -- "$mako_flatpak_command" "$mako_flatpak_subcommand" --env=VK_INSTANCE_LAYERS="${VK_INSTANCE_LAYERS}" --unset-env=ENABLE_MAKO --unset-env=DISABLE_MAKO --unset-env=ENABLE_GAMESCOPE_WSI --unset-env=DISABLE_GAMESCOPE_WSI --unset-env=ENABLE_MAKO_SPATIAL_SCALING --unset-env=DISABLE_MAKO_SPATIAL_SCALING "${@:3}"
    fi
    if [ -n "${MAKO_SPLIT_LAYER_CHAIN:-}" ]; then
        set -- "$mako_flatpak_command" "$mako_flatpak_subcommand" --env=MAKO_SPLIT_LAYER_CHAIN="${MAKO_SPLIT_LAYER_CHAIN}" "${@:3}"
    fi
    if [ "$mako_vkbasalt_enabled" = 1 ]; then
        set -- "$mako_flatpak_command" "$mako_flatpak_subcommand" --unset-env=DISABLE_VKBASALT "${@:3}"
        if [ "${ENABLE_VKBASALT:-0}" = 1 ]; then
            set -- "$mako_flatpak_command" "$mako_flatpak_subcommand" --env=ENABLE_VKBASALT=1 "${@:3}"
        fi
        if [ -n "${VKBASALT_CONFIG_FILE:-}" ]; then
            set -- "$mako_flatpak_command" "$mako_flatpak_subcommand" --env=VKBASALT_CONFIG_FILE="${VKBASALT_CONFIG_FILE}" --env=VKBASALT_CONFIG_RELOAD=1 "${@:3}"
        fi
    fi
    unset mako_flatpak_command
    unset mako_flatpak_subcommand
fi
unset mako_vkbasalt_config
unset mako_vkbasalt_enabled
unset mako_renderer_required
unset mako_renderer_enabled
unset mako_flatpak_runtime
unset mako_flatpak_launch
# Heroic can discard a game's stderr. Capture opt-in engine diagnostics here instead.
mako_diagnostics_default=/home/deck/.config/mako-render/present-diagnostics.log
mako_diagnostics_state=off
if [ "${MAKO_PRESENT_DIAGNOSTICS:-0}" != "0" ]; then
    mako_diagnostics_state=unavailable
    mako_diagnostics_log="${MAKO_PRESENT_DIAGNOSTICS_LOG:-$mako_diagnostics_default}"
    mako_diagnostics_rotation_ready=1
    for mako_diagnostics_entry in "$mako_diagnostics_log" "$mako_diagnostics_log.1" "$mako_diagnostics_log.2" "$mako_diagnostics_log.3" "$mako_diagnostics_log.4"; do
        if [ -L "$mako_diagnostics_entry" ] || { [ -e "$mako_diagnostics_entry" ] && { [ ! -f "$mako_diagnostics_entry" ] || [ ! -O "$mako_diagnostics_entry" ]; }; }; then
            mako_diagnostics_rotation_ready=0
            break
        fi
    done
    # A stale log or rotation owned by another user (or a symlink) used to disable
    # diagnostics silently. The default log lives in our own config dir: drop them.
    if [ "$mako_diagnostics_rotation_ready" = 0 ] && [ "$mako_diagnostics_log" = "$mako_diagnostics_default" ]; then
        mako_diagnostics_rotation_ready=1
        for mako_diagnostics_entry in "$mako_diagnostics_log" "$mako_diagnostics_log.1" "$mako_diagnostics_log.2" "$mako_diagnostics_log.3" "$mako_diagnostics_log.4"; do
            if [ -L "$mako_diagnostics_entry" ] || { [ -f "$mako_diagnostics_entry" ] && [ ! -O "$mako_diagnostics_entry" ]; }; then
                rm -f -- "$mako_diagnostics_entry" 2>/dev/null || mako_diagnostics_rotation_ready=0
            elif [ -e "$mako_diagnostics_entry" ] && [ ! -f "$mako_diagnostics_entry" ]; then
                mako_diagnostics_rotation_ready=0
            fi
        done
    fi
    if [ "$mako_diagnostics_rotation_ready" = 1 ] && [ -f "$mako_diagnostics_log" ]; then
        if [ "$mako_diagnostics_rotation_ready" = 1 ] && [ -f "$mako_diagnostics_log.3" ] && ! mv -fT -- "$mako_diagnostics_log.3" "$mako_diagnostics_log.4" 2>/dev/null; then
            mako_diagnostics_rotation_ready=0
        fi
        if [ "$mako_diagnostics_rotation_ready" = 1 ] && [ -f "$mako_diagnostics_log.2" ] && ! mv -fT -- "$mako_diagnostics_log.2" "$mako_diagnostics_log.3" 2>/dev/null; then
            mako_diagnostics_rotation_ready=0
        fi
        if [ "$mako_diagnostics_rotation_ready" = 1 ] && [ -f "$mako_diagnostics_log.1" ] && ! mv -fT -- "$mako_diagnostics_log.1" "$mako_diagnostics_log.2" 2>/dev/null; then
            mako_diagnostics_rotation_ready=0
        fi
        if [ "$mako_diagnostics_rotation_ready" = 1 ] && [ -f "$mako_diagnostics_log" ] && ! mv -fT -- "$mako_diagnostics_log" "$mako_diagnostics_log.1" 2>/dev/null; then
            mako_diagnostics_rotation_ready=0
        fi
    fi
    if [ "$mako_diagnostics_rotation_ready" = 1 ] && (set -C; : > "$mako_diagnostics_log") 2>/dev/null; then
        exec 2>> "$mako_diagnostics_log"
        mako_diagnostics_state=log
    else
        # Last resort: the Governor also reads this RAM log (newest wins).
        mako_diagnostics_log=/dev/shm/gfg-present-diagnostics.log
        if { [ ! -e "$mako_diagnostics_log" ] && [ ! -L "$mako_diagnostics_log" ] && (set -C; : > "$mako_diagnostics_log") 2>/dev/null; } || { [ ! -L "$mako_diagnostics_log" ] && [ -f "$mako_diagnostics_log" ] && [ -O "$mako_diagnostics_log" ] && : > "$mako_diagnostics_log"; }; then
            exec 2>> "$mako_diagnostics_log"
            mako_diagnostics_state=fallback
        fi
    fi
fi
unset mako_diagnostics_entry
if [ -n "${mako_gamescope_wsi_skip_log:-}" ]; then
    printf "%s\n" "$mako_gamescope_wsi_skip_log" >&2
fi
unset mako_gamescope_wsi_skip_log
# Keep the default renderer context active so a newly captured profile can take over live.
# A caller-provided MAKO_PROFILE remains an explicit hard override.
if [ -z "${MAKO_PROFILE:-}" ]; then
    export MAKO_PROFILE_FALLBACK=mako
fi
if [ -n "${gfg_manifest_path:-}" ]; then
    mkdir -p "$(dirname -- "$gfg_manifest_path")" 2>/dev/null || :
    gfg_json_escape() {
        local gfg_value="$1"
        gfg_value="${gfg_value//\\/\\\\}"
        gfg_value="${gfg_value//\"/\\\"}"
        printf "%s" "$gfg_value"
    }
    gfg_launch_app_id="${SteamAppId:-${SteamGameId:-${STEAM_COMPAT_APP_ID:-}}}"
    case "$gfg_launch_app_id" in *[!0-9]*) gfg_launch_app_id="" ;; esac
    gfg_launch_starttime="$(awk '{print $22}' "/proc/$$/stat" 2>/dev/null || printf 0)"
    case "$gfg_launch_starttime" in *[!0-9]*|"") gfg_launch_starttime=0 ;; esac
    gfg_launch_timestamp="$(date +%s 2>/dev/null || printf 0)"
    gfg_launch_profile="$(gfg_json_escape "${mako_wrapper_profile:-mako}")"
    gfg_launch_wrapper="$(gfg_json_escape "$0")"
    gfg_launch_command="$(gfg_json_escape "${1:-}")"
    gfg_launch_governor=""
    if [ -n "${mako_governor_overlay_active:-}" ]; then
        gfg_launch_governor="$(sed -n 's/^# gfg-governor-launch: //p' "$mako_governor_overlay_active" 2>/dev/null | head -n 1)"
        gfg_launch_governor="$(gfg_json_escape "$gfg_launch_governor")"
    fi
    gfg_launch_tmp="${gfg_manifest_path}.tmp.$$"
    printf '{"schema":1,"timestamp":%s,"pid":%s,"starttime":%s,"app_id":"%s","profile":"%s","wrapper":"%s","command":"%s","saved":{"fg_backend":"%s","frame_generation_enabled":%s,"automatic_dock_mode":%s},"effective":{"frame_generation_enabled":%s,"automatic_dock_mode":%s,"scaling_enabled":%s,"shaders_enabled":%s,"renderer_required":%s,"target_fps":%s},"optiscaler_proxy":"%s","governor_launch":"%s"}\n' "$gfg_launch_timestamp" "$$" "$gfg_launch_starttime" "$gfg_launch_app_id" "$gfg_launch_profile" "$gfg_launch_wrapper" "$gfg_launch_command" "$gfg_manifest_saved_backend" "$gfg_manifest_saved_fg" "$gfg_manifest_saved_dock" "$gfg_manifest_effective_fg" "$gfg_manifest_effective_dock" "$gfg_manifest_scaling" "$gfg_manifest_shaders" "$gfg_manifest_renderer_required" "$gfg_manifest_target_fps" "$gfg_manifest_proxy" "$gfg_launch_governor" > "$gfg_launch_tmp" 2>/dev/null && mv -f "$gfg_launch_tmp" "$gfg_manifest_path" || rm -f "$gfg_launch_tmp"
    gfg_activity_log="$(dirname -- "$(dirname -- "$gfg_manifest_path")")/activity.jsonl"
    gfg_launch_overlay=inactive
    [ -n "${mako_governor_overlay_active:-}" ] && gfg_launch_overlay=active
    printf '{"ts":%s,"source":"wrapper","kind":"game-launch","pid":%s,"app_id":"%s","profile":"%s","command":"%s","diagnostics":"%s","diagnostics_log":"%s","governor_overlay":"%s","vk_instance_layers":"%s"}\n' "$gfg_launch_timestamp" "$$" "$gfg_launch_app_id" "$gfg_launch_profile" "$gfg_launch_command" "${mako_diagnostics_state:-off}" "$(gfg_json_escape "${mako_diagnostics_log:-}")" "$gfg_launch_overlay" "$(gfg_json_escape "${VK_INSTANCE_LAYERS:-}")" >> "$gfg_activity_log" 2>/dev/null || :
    unset gfg_activity_log gfg_launch_overlay
    unset -f gfg_json_escape
fi
unset mako_diagnostics_state mako_diagnostics_log
if [ -n "${GAMESCOPE_WAYLAND_DISPLAY:-}" ] && { [ -z "${WAYLAND_DISPLAY:-}" ] || [ "${WAYLAND_DISPLAY}" = "${GAMESCOPE_WAYLAND_DISPLAY}" ]; } && [ -x /home/deck/.local/share/mako-render/bin/mako-vrr-lease ]; then
    export MAKO_VRR_LEASE_TOKEN="$$-$RANDOM-$RANDOM"
    /home/deck/.local/share/mako-render/bin/mako-vrr-lease --start "$$" "$MAKO_VRR_LEASE_TOKEN" || :
fi
exec "$@"
