GFG Extreme diagnostic log.
profile: mako
duration_s: 189.7
summary.txt      plain-language verdict of this log (read this first)
timeline.jsonl   1 Hz Governor state (state, reason, real/output FPS, point, ladder, TDP, overlay)
self_test.json   every precondition with ok/detail
system.json      device, kernel, gamescope
diagnostics-*.log renderer diagnostics appended during the recording
governor-events.jsonl  Governor decisions during the recording
activity.jsonl   your actions (UI clicks, game launches/exits), Governor states, TDP writes;
                 starts 30 min before the recording
launch-wrapper.sh the generated launcher
overlay/         in-game overlay config and status line
game-processes.json  layer env of the running game and whether MangoHud was loaded
power-sensors.json   every hwmon power cap/draw at start and end of the recording
profile.json     saved profile
plugin.log       tail of the Decky plugin log
