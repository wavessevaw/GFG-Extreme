/* Host tests for the control channel (seqlock, file policy, rate limit, version gate, modes,
 * generation, heartbeat, telemetry ownership, env mode) and the layer-side metrics. */
#define _GNU_SOURCE
#include "../src/control.h"
#include "../src/metrics.h"

#include <fcntl.h>
#include <math.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

static int failures = 0;
#define CHECK(cond, ...) do { if (!(cond)) { failures++; printf("FAIL %s:%d: ", __FILE__, __LINE__); \
    printf(__VA_ARGS__); printf("\n"); } } while (0)

#define MS 1000000ll

static char path[256];

/* The Governor's side: create the file (file_size bytes) and map it. */
static gfg_ctl_shm *governor_create_sized(uint32_t version, size_t file_size)
{
    int fd = open(path, O_RDWR | O_CREAT | O_TRUNC, 0600);
    if (fd < 0 || ftruncate(fd, (off_t)file_size) != 0)
        return NULL;
    gfg_ctl_shm *m = mmap(NULL, sizeof(*m), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    if (m == MAP_FAILED)
        return NULL;
    gfg_ctl_init_header(m);
    m->version = version;
    if (file_size < sizeof(gfg_ctl_shm))
        m->size = (uint32_t)file_size;
    return m;
}

static gfg_ctl_shm *governor_create(uint32_t version)
{
    return governor_create_sized(version, sizeof(gfg_ctl_shm));
}

static gfg_ctl_policy policy(double hz)
{
    gfg_ctl_policy p = { .enabled = 1, .tick_shaping = 1, .pacing = 1, .mode = GFG_MODE_ACT, .real_target_hz = hz,
                         .margin_ms = 3.0 };
    return p;
}

/* Governor write with a fresh heartbeat at t. */
static void put(gfg_ctl_shm *m, gfg_ctl_policy *p, int64_t t)
{
    p->written_ns = t;
    gfg_ctl_write_policy(m, p);
}

static void test_seqlock(void)
{
    gfg_ctl_shm shm;
    gfg_ctl_init_header(&shm);
    gfg_ctl_policy in = policy(60), out;
    gfg_ctl_write_policy(&shm, &in);
    CHECK(gfg_ctl_read_policy(&shm, &out) == 0 && out.real_target_hz == 60 && out.margin_ms == 3.0, "policy roundtrip");
    CHECK(shm.policy_seq == 2, "seq %u", shm.policy_seq);
    shm.policy_seq = 3;   /* writer mid-update */
    CHECK(gfg_ctl_read_policy(&shm, &out) == -1, "odd seq must read as busy");
    gfg_ctl_write_policy(&shm, &in);   /* a writer that died mid-way is recovered by the next one */
    CHECK(shm.policy_seq == 4 && gfg_ctl_read_policy(&shm, &out) == 0, "seq recovery %u", shm.policy_seq);
    gfg_ctl_telemetry t = { .frames = 7, .hits = 6, .misses = 1, .avg_delay_ms = 4.5 }, r;
    gfg_ctl_write_telemetry(&shm, &t);
    CHECK(gfg_ctl_read_telemetry(&shm, &r) == 0 && r.frames == 7 && r.avg_delay_ms == 4.5, "telemetry roundtrip");
}

static void test_file_policy(void)
{
    gfg_ctl_state st;
    int64_t t = 1000 * MS;
    unlink(path);
    gfg_ctl_shutdown();
    CHECK(gfg_ctl_poll(t, &st) == 0 && !st.enabled, "missing file must be disabled");

    gfg_ctl_shm *m = governor_create(GFG_CTL_VERSION);
    CHECK(m != NULL, "create %s", path);
    if (!m)
        return;
    gfg_ctl_policy p = policy(60);
    put(m, &p, t);
    t += 100 * MS;
    CHECK(gfg_ctl_poll(t, &st) == 0 && st.enabled && st.policy.real_target_hz == 60 && st.policy.margin_ms == 3.0,
          "file policy enabled=%d hz=%.1f", st.enabled, st.policy.real_target_hz);
    uint64_t serial = st.serial;
    CHECK(st.mode == GFG_MODE_ACT && st.generation == 0, "mode act, generation 0");
    CHECK(m->writer_pid == 0, "writer pid is set on publish, not on map (%u)", m->writer_pid);

    p.real_target_hz = 30;
    put(m, &p, t);
    gfg_ctl_poll(t + 50 * MS, &st);
    CHECK(st.policy.real_target_hz == 60 && st.serial == serial, "re-read before 100 ms");
    gfg_ctl_poll(t + 100 * MS, &st);
    CHECK(st.policy.real_target_hz == 30 && st.serial == serial + 1, "re-read after 100 ms: hz %.1f", st.policy.real_target_hz);
    t += 100 * MS;

    p.generation = 7;   /* same policy, new id: still a change (the ack must follow) */
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(st.generation == 7 && st.serial == serial + 2, "generation %u", st.generation);

    p.mode = GFG_MODE_OBSERVE;
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(st.enabled && st.mode == GFG_MODE_OBSERVE, "mode observe");
    p.mode = GFG_MODE_SHADOW;
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(st.enabled && st.mode == GFG_MODE_SHADOW, "mode shadow");
    p.mode = 3;
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "unknown mode must be disabled");
    p.mode = GFG_MODE_ACT;

    gfg_ctl_telemetry tel = { .frames = 42, .hits = 40, .misses = 2, .cost_p50_ms = 5.0, .freshness_ms = 9.5,
                              .last_present_ns = t, .applied_generation = 7, .swapchain_recreations = 2,
                              .present_hold_ms = 20.5, .acquire_block_ms = 0.25, .last_present_return_ns = t + 20 * MS,
                              .engine = "DXVK" };
    CHECK(gfg_ctl_publish(&tel) == 1, "publish");
    gfg_ctl_telemetry r;
    CHECK(gfg_ctl_read_telemetry(m, &r) == 0 && r.frames == 42 && r.cost_p50_ms == 5.0 && r.last_present_ns == t &&
          r.freshness_ms == 9.5 && r.applied_generation == 7 && r.swapchain_recreations == 2 &&
          r.present_hold_ms == 20.5 && r.acquire_block_ms == 0.25 && r.last_present_return_ns == t + 20 * MS &&
          !strcmp(r.engine, "DXVK") && !r.passthrough,
          "telemetry frames %llu", (unsigned long long)r.frames);
    CHECK(m->writer_pid == (uint32_t)getpid(), "writer pid %u after publish", m->writer_pid);

    /* another process publishes: its telemetry is not overwritten while it is fresh */
    m->writer_pid = 2000000000u; /* known dead PID, not a coincidentally live neighbor */
    tel.frames = 43;
    tel.last_present_ns = t + 400 * MS;
    CHECK(gfg_ctl_publish(&tel) == 0 && m->telemetry.frames == 42, "fresh foreign telemetry kept");
    gfg_ctl_mark_passthrough(t + 400 * MS);
    CHECK(!m->telemetry.passthrough, "passthrough flag follows the same rule");
    tel.last_present_ns = t + 501 * MS;
    CHECK(gfg_ctl_publish(&tel) == 1 && m->telemetry.frames == 43 && m->writer_pid == (uint32_t)getpid(),
          "takeover after 500 ms of silence");
    gfg_ctl_mark_passthrough(t + 502 * MS);
    CHECK(m->telemetry.passthrough == 1 && m->telemetry.frames == 43, "passthrough flagged");

    /* A crashed Governor can leave a permanently odd policy seq. Even if the
     * last acknowledged policy was Act, it must expire without fresh writes. */
    p = policy(45);
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(st.enabled && st.mode == GFG_MODE_ACT, "fresh Act before odd seqlock");
    m->policy_seq |= 1u;
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(st.enabled, "transient odd seqlock may retain last good policy");
    t += GFG_CTL_HEARTBEAT_NS + 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "stuck odd seqlock must fail closed after heartbeat window");
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(st.enabled && st.mode == GFG_MODE_ACT, "fresh policy resumes after recovery");

    /* A live second Vulkan process may be idle > 500 ms but can resume writing.
     * Never steal its ownership merely because its last present became stale. */
    pid_t child = fork();
    if (child == 0) {
        for (;;) pause();
    }
    CHECK(child > 0, "fork live telemetry writer");
    if (child > 0) {
        m->writer_pid = (uint32_t)child;
        tel.last_present_ns += 2000 * MS;
        CHECK(gfg_ctl_publish(&tel) == 0 && m->writer_pid == (uint32_t)child,
              "live process must retain ownership even when telemetry aged");
        kill(child, SIGKILL);
        waitpid(child, NULL, 0);
        CHECK(gfg_ctl_publish(&tel) == 1 && m->writer_pid == (uint32_t)getpid(),
              "dead owner can be replaced after telemetry timeout");
    }

    /* A timestamp from a future/different clock must never arm Act. */
    p = policy(60);
    put(m, &p, t + 10000 * MS);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "future heartbeat must be disabled");

    /* Reading a nearly expired policy must not grant another heartbeat window
     * when its writer subsequently dies in the middle of a seqlock update. */
    put(m, &p, t);
    t += GFG_CTL_HEARTBEAT_NS - 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(st.enabled, "nearly expired heartbeat still valid");
    m->policy_seq |= 1u;
    t += 200 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "cached policy expires from written timestamp, not read time");

    /* heartbeat: a policy the Governor stopped rewriting is not trusted */
    p = policy(60);
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(st.enabled, "fresh heartbeat");
    t += GFG_CTL_HEARTBEAT_NS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "heartbeat older than 2 s must be disabled");
    p.written_ns = 0;
    gfg_ctl_write_policy(m, &p);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "no heartbeat must be disabled");
    p = policy(30);

    p.real_target_hz = NAN;
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "NaN policy must be disabled");

    p = policy(60);
    p.enabled = 0;
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "enabled=0");

    munmap(m, sizeof(*m));
    m = governor_create(GFG_CTL_VERSION + 1);   /* recreated file, other version */
    p = policy(60);
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "version mismatch must be disabled");


    munmap(m, sizeof(*m));
    m = governor_create(GFG_CTL_VERSION);       /* recreated again (new inode), right version */
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(st.enabled && st.policy.real_target_hz == 60, "remap after recreate");
    munmap(m, sizeof(*m));
    m = governor_create_sized(1, 136);          /* a version-1 file (136 bytes), policy enabled */
    put(m, &p, t);               /* v1 had enabled/hz at the same offsets */
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "version-1 file must be disabled");
    munmap(m, sizeof(*m));
    m = governor_create_sized(2, 176);          /* a version-2 file (176 bytes): policy at the same offsets */
    put(m, &p, t);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "version-2 file must be disabled");
    gfg_ctl_publish(&tel);
    CHECK(m->telemetry_seq == 0 && m->writer_pid == 0, "version-2 file not written");
    munmap(m, sizeof(*m));
    unlink(path);
    t += 100 * MS;
    gfg_ctl_poll(t, &st);
    CHECK(!st.enabled, "file removed");
    gfg_ctl_shutdown();
}

static void test_env_mode(void)
{
    gfg_ctl_state st;
    unlink(path);
    setenv("GFG_FRAME_OS_ENABLE", "1", 1);
    setenv("GFG_FRAME_OS_REAL_HZ", "45", 1);
    setenv("GFG_FRAME_OS_PACING", "0", 1);
    setenv("GFG_FRAME_OS_MODE", "bogus", 1);
    gfg_ctl_shutdown();
    CHECK(gfg_ctl_poll(1, &st) == 0 && !st.enabled && access(path, F_OK) != 0, "unknown env mode must be disabled");
    setenv("GFG_FRAME_OS_MODE", "shadow", 1);
    gfg_ctl_shutdown();
    CHECK(gfg_ctl_poll(1, &st) == 0 && st.enabled && st.policy.real_target_hz == 45 && !st.policy.pacing &&
          st.policy.tick_shaping && st.mode == GFG_MODE_SHADOW && st.generation == 0, "env policy");
    CHECK(access(path, F_OK) == 0, "env mode creates the file for telemetry");
    gfg_ctl_telemetry tel = { .frames = 3 };
    gfg_ctl_publish(&tel);
    int fd = open(path, O_RDONLY);
    gfg_ctl_shm shm;
    CHECK(fd >= 0 && read(fd, &shm, sizeof(shm)) == (ssize_t)sizeof(shm) && shm.magic == GFG_CTL_MAGIC &&
          shm.telemetry.frames == 3, "telemetry in created file");
    if (fd >= 0)
        close(fd);
    gfg_ctl_shutdown();
    CHECK(access(path, F_OK) != 0, "created file removed at shutdown");
    unsetenv("GFG_FRAME_OS_ENABLE");
    unsetenv("GFG_FRAME_OS_MODE");
}

static void test_metrics(void)
{
    gfg_ring r = {0};
    CHECK(gfg_ring_quantile(&r, 0.5) == 0, "empty ring");
    for (int i = 1; i <= 100; i++)
        gfg_ring_push(&r, i);                   /* keeps the last 64: 37..100 */
    CHECK(r.count == GFG_RING_LEN && gfg_ring_quantile(&r, 0) == 37 && gfg_ring_quantile(&r, 1) == 100,
          "ring window %.0f..%.0f", gfg_ring_quantile(&r, 0), gfg_ring_quantile(&r, 1));
    CHECK(fabs(gfg_ring_quantile(&r, 0.5) - 68.5) <= 0.5, "p50 %.1f", gfg_ring_quantile(&r, 0.5));

    /* 60 Hz presents; frame starts 10 ms before the release, ready 4 ms after the start */
    gfg_metrics m;
    gfg_metrics_reset(&m);
    int64_t t = 1000 * MS;
    for (int i = 0; i < 100; i++) {
        int64_t release = t + i * 16666667ll;
        gfg_metrics_frame_start(&m, release - 10 * MS);
        gfg_metrics_ready(&m, release - 6 * MS);
        gfg_metrics_released(&m, release, release);
    }
    CHECK(m.frames == 100, "frames %llu", (unsigned long long)m.frames);
    CHECK(fabs(m.freshness_ms - 10.0) < 1e-6, "freshness %.3f", m.freshness_ms);
    CHECK(fabs(gfg_ring_quantile(&m.costs_ms, 0.5) - 4.0) < 1e-6, "cost p50 %.3f", gfg_ring_quantile(&m.costs_ms, 0.5));
    CHECK(fabs(gfg_ring_quantile(&m.intervals_ms, 0.95) - 16.667) < 0.01, "interval p95 %.3f",
          gfg_ring_quantile(&m.intervals_ms, 0.95));
    /* EWMA: one 30 ms-old frame moves freshness by alpha * 20 ms */
    gfg_metrics_frame_start(&m, t + 100 * 16666667ll - 30 * MS);
    gfg_metrics_released(&m, t + 100 * 16666667ll, t + 100 * 16666667ll);
    CHECK(fabs(m.freshness_ms - (10.0 + GFG_FRESHNESS_ALPHA * 20.0)) < 1e-6, "freshness EWMA %.3f", m.freshness_ms);
    /* present without a known start: no freshness/cost sample, still counted */
    gfg_metrics_released(&m, t + 101 * 16666667ll, t + 101 * 16666667ll);
    CHECK(m.frames == 102 && fabs(m.freshness_ms - 11.0) < 1e-6, "no-start present");
    /* a frame generator below holds the present 20 ms: freshness counts until the return */
    gfg_metrics_reset(&m);
    for (int i = 0; i < 200; i++) {
        int64_t release = t + i * 33333333ll;
        gfg_metrics_frame_start(&m, release - 10 * MS);
        gfg_metrics_released(&m, release, release + 20 * MS);
        gfg_metrics_acquired(&m, 2 * MS);
    }
    CHECK(fabs(m.freshness_ms - 30.0) < 1e-6 && fabs(m.present_hold_ms - 20.0) < 1e-6 &&
          fabs(m.acquire_block_ms - 2.0) < 1e-6, "freshness %.3f hold %.3f acquire block %.3f", m.freshness_ms,
          m.present_hold_ms, m.acquire_block_ms);
}

int main(void)
{
    snprintf(path, sizeof(path), "/dev/shm/gfg-frame-os-test-%d", (int)getpid());
    setenv("GFG_FRAME_OS_SHM", path, 1);
    test_seqlock();
    test_file_policy();
    test_env_mode();
    test_metrics();
    unlink(path);
    if (failures) {
        printf("%d control check(s) failed\n", failures);
        return 1;
    }
    printf("control channel + metrics: all checks passed\n");
    return 0;
}
