/* GFG Frame OS — Presentation Scheduler core.  See scheduler.h. */
#include "scheduler.h"

#include <math.h>
#include <string.h>

#define NS_PER_MS 1000000.0
#define MIN_COST_SAMPLES 8
#define RECENT_COSTS 32
#define FAST_ALPHA 0.25
#define SLOW_ALPHA 0.03
#define TREND_DEADBAND_MS 0.3   /* floor; the band also scales with the cost spread */

void gfg_policy_defaults(gfg_policy *p)
{
    memset(p, 0, sizeof(*p));
    p->real_target_hz = 0.0;
    p->tick_shaping = 1;
    p->pacing = 1;
    p->margin_ms = 2.0;
    p->min_margin_ms = 1.0;
    p->max_margin_ms = 8.0;
    p->max_wait_ms = 11.0;   /* one 90 Hz refresh */
    p->cost_quantile = 0.95;
    p->predictive = 1;
}

static int64_t period_for(const gfg_policy *p)
{
    if (!(p->real_target_hz > 0.0) || !isfinite(p->real_target_hz))
        return 0;
    return (int64_t)llround(1e9 / p->real_target_hz);
}

static double clamp(double v, double lo, double hi)
{
    return v < lo ? lo : (v > hi ? hi : v);
}

void gfg_sched_init(gfg_sched *s, const gfg_policy *policy)
{
    memset(s, 0, sizeof(*s));
    s->policy = *policy;
    s->period_ns = period_for(policy);
    s->margin_ms = clamp(policy->margin_ms, policy->min_margin_ms, policy->max_margin_ms);
    s->stats.margin_ms = s->margin_ms;
}

void gfg_sched_set_policy(gfg_sched *s, const gfg_policy *policy)
{
    int64_t period = period_for(policy);
    s->policy = *policy;
    if (period != s->period_ns) {
        s->period_ns = period;
        s->next_slot_ns = 0;   /* re-anchor the grid on the next present */
    }
    s->margin_ms = clamp(s->margin_ms, policy->min_margin_ms, policy->max_margin_ms);
}

static int cmp_double(const void *a, const void *b)
{
    double x = *(const double *)a, y = *(const double *)b;
    return (x > y) - (x < y);
}

/* Quantile of the newest `last` costs (all when last >= count). */
static double quantile_last(const gfg_sched *s, double q, int last)
{
    double sorted[GFG_COST_WINDOW];
    int n = s->cost_count, i, j;
    if (n <= 0)
        return 0.0;
    if (last > 0 && last < n) {
        for (i = 0; i < last; i++)
            sorted[i] = s->costs_ms[(s->cost_head - 1 - i + GFG_COST_WINDOW) % GFG_COST_WINDOW];
        n = last;
    } else {
        memcpy(sorted, s->costs_ms, sizeof(double) * (size_t)n);
    }
    /* insertion sort: n <= 64, called once per frame */
    for (i = 1; i < n; i++) {
        double v = sorted[i];
        for (j = i - 1; j >= 0 && cmp_double(&sorted[j], &v) > 0; j--)
            sorted[j + 1] = sorted[j];
        sorted[j + 1] = v;
    }
    q = clamp(q, 0.0, 1.0);
    i = (int)llround(q * (n - 1));
    return sorted[i];
}

double gfg_sched_cost_quantile(const gfg_sched *s, double q)
{
    return quantile_last(s, q, 0);
}

/* The frame cost to plan the next start with (ms). */
static double planned_cost(const gfg_sched *s)
{
    const gfg_policy *p = &s->policy;
    double all = gfg_sched_cost_quantile(s, p->cost_quantile);
    if (!p->predictive || s->cost_count < 2 * MIN_COST_SAMPLES)
        return all;
    double trend = s->cost_fast_ms - s->cost_slow_ms;
    double recent = quantile_last(s, p->cost_quantile, RECENT_COSTS);
    /* Ordinary frame-to-frame noise moves the fast average too: only a trend clearly beyond the
     * recent spread (p90 - p50) is a scene changing weight (review: a fixed 0.3 ms band flipped
     * the plan every frame at 1.5 ms jitter). */
    double spread = recent - quantile_last(s, 0.5, RECENT_COSTS);
    double band = 0.5 * spread > TREND_DEADBAND_MS ? 0.5 * spread : TREND_DEADBAND_MS;
    if (trend > band) {
        double ahead = recent + trend;            /* the scene is getting heavier: plan ahead */
        return ahead > all ? ahead : all;
    }
    if (trend < -band) {
        /* lighter: the old heavy frames no longer say anything about the next one */
        return recent > s->cost_fast_ms ? recent : s->cost_fast_ms;
    }
    return all;
}

static void record_cost(gfg_sched *s, double cost_ms)
{
    if (!(cost_ms >= 0.0) || !isfinite(cost_ms))
        return;
    if (s->cost_count == 0) {
        s->cost_fast_ms = s->cost_slow_ms = cost_ms;
    } else {
        s->cost_fast_ms += FAST_ALPHA * (cost_ms - s->cost_fast_ms);
        s->cost_slow_ms += SLOW_ALPHA * (cost_ms - s->cost_slow_ms);
    }
    s->costs_ms[s->cost_head] = cost_ms;
    s->cost_head = (s->cost_head + 1) % GFG_COST_WINDOW;
    if (s->cost_count < GFG_COST_WINDOW)
        s->cost_count++;
}

int64_t gfg_sched_frame_start(gfg_sched *s, int64_t now_ns)
{
    const gfg_policy *p = &s->policy;
    int64_t delay = 0;
    if (s->period_ns > 0 && p->tick_shaping && s->next_slot_ns > 0 && s->cost_count >= MIN_COST_SAMPLES) {
        double cost_q = planned_cost(s);
        int64_t cost_ns = (int64_t)llround(cost_q * NS_PER_MS);
        int64_t plan_ns = (int64_t)llround((cost_q + s->margin_ms) * NS_PER_MS);
        int64_t slot = s->next_slot_ns;
        if (plan_ns >= s->period_ns) {
            /* Frames as long as the slot: nothing queues, there is nothing to shape. */
            s->frame_start_ns = now_ns;
            s->stats.last_delay_ms = 0.0;
            return 0;
        }
        /* A late/heavy frame must start now. Advancing to a future grid slot
         * here adds a second delay on top of rendering and can halve real FPS. */
        if (slot < now_ns + cost_ns) {
            s->frame_start_ns = now_ns;
            s->stats.last_delay_ms = 0.0;
            return 0;
        }
        s->next_slot_ns = slot;
        if (slot - plan_ns > now_ns)
            delay = slot - plan_ns - now_ns;
        int64_t cap = (int64_t)llround(p->max_wait_ms * NS_PER_MS);
        if (delay > cap)
            delay = cap;
    }
    s->frame_start_ns = now_ns + delay;
    s->stats.last_delay_ms = (double)delay / NS_PER_MS;
    s->stats.avg_delay_ms = s->stats.frames ? 0.95 * s->stats.avg_delay_ms + 0.05 * s->stats.last_delay_ms
                                            : s->stats.last_delay_ms;
    return delay;
}

int64_t gfg_sched_present(gfg_sched *s, int64_t ready_ns)
{
    const gfg_policy *p = &s->policy;
    int64_t release = ready_ns;
    if (s->frame_start_ns > 0 && ready_ns >= s->frame_start_ns)
        record_cost(s, (double)(ready_ns - s->frame_start_ns) / NS_PER_MS);
    s->stats.frames++;

    if (s->period_ns > 0) {
        int64_t slot = s->next_slot_ns;
        if (slot <= 0) {
            slot = ready_ns;   /* anchor the grid on the first present */
        } else if (ready_ns <= slot) {
            s->stats.hits++;
            s->margin_ms = clamp(s->margin_ms * 0.995, p->min_margin_ms, p->max_margin_ms);  /* slow give-back */
        } else {
            /* Missing 33.33 ms by even 0.1 ms must not wait for 66.67 ms.
             * Present a ready late frame immediately and re-anchor. This is
             * basic pacing correctness, independent of the optional shield. */
            slot = ready_ns;
            s->stats.misses++;
            s->margin_ms = clamp(s->margin_ms * 1.5 + 0.5, p->min_margin_ms, p->max_margin_ms);
        }
        if (p->pacing && slot > ready_ns) {
            int64_t cap = (int64_t)llround(p->max_wait_ms * NS_PER_MS);
            if (p->stall_shield && cap >= 0 && slot - ready_ns > cap)
                slot = ready_ns + cap;  /* bound this wait and re-anchor the following slot */
            release = slot;
        }
        s->next_slot_ns = slot + s->period_ns;
    }
    s->frame_start_ns = 0;
    s->stats.margin_ms = s->margin_ms;
    s->stats.cost_p50_ms = gfg_sched_cost_quantile(s, 0.5);
    s->stats.cost_q_ms = gfg_sched_cost_quantile(s, p->cost_quantile);
    return release;
}

const gfg_stats *gfg_sched_stats(const gfg_sched *s)
{
    return &s->stats;
}
