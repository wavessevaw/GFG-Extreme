import * as React from "react";
import { createRoot } from "react-dom/client";
window.React = React; window.__createRoot = createRoot;
