"""In-game HUD: MangoHud config + a one-line Governor status file.

MangoHud is already shipped as a managed Vulkan layer.  The HUD shows MangoHud's
own presented-FPS/frametime plus one ``exec`` line fed from a status file the
Governor service keeps current.  Whether MangoHud re-runs ``exec`` at a useful
cadence is unverified and must be confirmed on a Deck (see known limitations).
"""
from __future__ import annotations

import os
import math
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

from .governor_battery import format_minutes

PRESETS = ("minimal", "standard", "detailed")
POSITIONS = ("top-left", "top-right", "bottom-left", "bottom-right")
HUD_DIRNAME = "hud"
STATUS_FILENAME = "status.txt"

_STATE_WORD = {
    "LOCKED": "locked", "OPTIMIZE_POWER": "saving power", "GUARD": "guard",
    "APPLY": "testing", "PROBE": "measuring", "PLAN": "measuring",
    "OBSERVE_ONLY": "observing", "PAUSED": "paused", "DISABLED": "off",
}


def normalize(preset: Any, position: Any) -> tuple[str, str]:
    preset = str(preset or "standard").lower()
    position = str(position or "top-right").lower()
    return (preset if preset in PRESETS else "standard",
            position if position in POSITIONS else "top-right")


def status_path(config_dir: Path) -> Path:
    return Path(config_dir) / HUD_DIRNAME / STATUS_FILENAME


def active_config_path(config_dir: Path) -> Path:
    """The file the launch wrapper looks for; present only while the HUD is on."""
    return Path(config_dir) / HUD_DIRNAME / "active.conf"


def _fmt_multiplier(value: float) -> str:
    """Nearest quarter step: 2.01 -> 2, 1.46 -> 1.5, 1.76 -> 1.75."""
    q = round(float(value) * 4) / 4
    return str(int(q)) if q == int(q) else f"{q:g}"


_EFFORT_SHORT = {"easy": "easy", "medium": "med", "hard": "hard", "nightmare": "nightmare"}


def _number(value: Any) -> Optional[float]:
    return (float(value) if isinstance(value, (int, float)) and not isinstance(value, bool)
            and math.isfinite(value) and value >= 0 else None)


def telemetry_values(status: Dict[str, Any]) -> tuple:
    """Use fresh interval samples in both HUD styles; do not average over old scenes."""
    tel = status.get("telemetry") or {}
    snapshot = tel.get("snapshot")
    if snapshot is not None:
        age = _number(snapshot.get("sample_age_ms"))
        latest = snapshot.get("latest") or {}
        if age is None or age > 2500 or latest.get("output_source") == "instant_plan":
            return None, None, None
        real, out = _number(latest.get("real_fps")), _number(latest.get("output_fps"))
        mult = out / real if real and out is not None else _number(latest.get("effective_multiplier"))
    else:
        summary = tel.get("summary") or tel
        real = _number((summary.get("real") or {}).get("median"))
        out = _number((summary.get("output") or {}).get("median"))
        mult = out / real if real and out is not None else _number((summary.get("multiplier") or {}).get("median"))
        if mult is None:
            mult = _number((summary.get("latest") or {}).get("effective_multiplier"))
    return real, out, mult


def output_fps(status: Dict[str, Any]) -> Optional[float]:
    """Fresh output FPS also works with a HUD-only (Governor-off) session."""
    if not status.get("enabled") and (status.get("telemetry") or {}).get("snapshot") is None:
        return None
    return telemetry_values(status)[1]


def frame_os_word(frame_os: Any) -> str:
    """Requested boost is labelled verifying; observe-only decisions carry a question mark."""
    if not isinstance(frame_os, dict) or not frame_os.get("enabled"):
        return ""
    if not (frame_os.get("telemetry") or {}).get("live"):
        return ""
    decision = frame_os.get("decision") or {}
    level, real = decision.get("level"), _number(decision.get("real_hz"))
    if level not in ("boost", "calm", "rest") or real is None:
        return ""
    # A requested boost is not measured delivery; the ring HUD verifies it separately.
    label = "verifying" if level == "boost" and frame_os.get("acting") else level
    return f"FOS {label}{'' if frame_os.get('acting') else '?'} {round(real)}"


def status_line(status: Dict[str, Any], preset: str = "standard") -> str:
    """Compact: ``90 FPS x2 (45) sc100 9W 2h05 med`` (two spaces between fields).

    The lead number is the output FPS with generated frames; the real (rendered)
    FPS follows the multiplier in brackets.
    """
    if not status.get("enabled") and output_fps(status) is None:
        return "GFG off"
    real, out, mult = telemetry_values(status)
    parts = [f"{round(out)} FPS"] if out is not None else []
    parts.append(f"x{_fmt_multiplier(mult)}" if mult else "GFG")
    if real is not None and out is not None:
        parts.append(f"({round(real)})")
    if preset == "minimal":
        return "  ".join(parts)
    point = status.get("active_point") or {}
    ext = status.get("extreme") or {}
    if ext.get("enabled"):
        # A requested point is not renderer evidence. Keep the last confirmed scale,
        # or show unknown while the first request is still being verified.
        pct = (ext.get("applied") or {}).get("render_pct")
        parts.append(f"sc{round(pct)}" if _number(pct) is not None else "sc?")
        parts.append("EXT")
    else:
        pct = _number(point.get("render_scale_pct", 100))
        parts.append(f"sc{round(pct)}" if pct is not None else "sc?")
    power = status.get("power") or {}
    tdp = _number(power.get("observed_tdp_w"))
    if tdp is None:
        tdp = _number(power.get("current_tdp_w"))
    draw = _number(power.get("draw_w"))
    if tdp is not None and draw is not None:
        # Limit and measured APU draw side by side: the limit alone proves nothing.
        parts.append(f"TDP {round(tdp)}W  APU {round(draw)}W")
    else:
        parts.append(f"{round(tdp)}W" if tdp is not None else "TDPn/a")
    minutes = _number((status.get("battery") or {}).get("minutes_left"))
    left = format_minutes(round(minutes) if minutes is not None else None)
    if left:
        parts.append(left)
    effort = (status.get("effort") or {}).get("level")
    if effort:
        parts.append(_EFFORT_SHORT.get(effort, str(effort)))
    if (status.get("diagnosis") or {}).get("thermal") == "hot":
        parts.append("HOT")
    fos = frame_os_word(status.get("frame_os"))
    if fos:
        parts.append(fos)
    if preset == "detailed":
        parts.append(_STATE_WORD.get(str(status.get("state")), "on"))
    return "  ".join(parts)


def mangohud_config(preset: str, position: str, status_file: Path, generated_fps: bool = False) -> str:
    """Compact horizontal bar.  No CPU load; GPU only in Detailed.

    ``generated_fps``: the status line already leads with the output FPS
    (generated frames included), so MangoHud's own counter is left out to avoid
    a second, different number.  Without renderer telemetry MangoHud's counter
    is the only FPS available and stays.  ``horizontal_stretch=0`` keeps the bar
    as wide as its content; stretched, it spans the screen and its text starts
    at the left edge whatever the position.
    """
    preset, position = normalize(preset, position)
    lines = [
        f"position={position}", "legacy_layout=0", "horizontal", "horizontal_stretch=0",
        "background_alpha=0.4", "font_size=18", "round_corners=6", "text_color=FFFFFF",
        "fps_color_change=0", "no_display=0",
        f"exec=cat {status_file}",
    ]
    if not generated_fps:
        lines += ["fps", "frametime"]
    if preset != "minimal":
        # Native MangoHud sensors: still useful if the `exec` status line is not refreshed on a given build.
        lines += ["gpu_power", "battery", "battery_time"]
    if preset == "detailed":
        lines += ["gpu_stats"]
    return "\n".join(lines) + "\n"


# Loaded with every managed launch while the HUD is off: MangoHud draws nothing.
HIDDEN_CONFIG = "no_display=1\n"


def _atomic(path: Path, text: str) -> bool:
    """Write only on change.  Returns True if the file was rewritten."""
    try:
        if path.read_text(encoding="utf-8") == text:
            return False
    except OSError:
        pass
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.chmod(tmp, 0o644)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return True


class HudWriter:
    """Owns the MangoHud config.  A running MangoHud re-reads it on every change.

    Field log: a game crashed seconds after six overlay changes in eight seconds.
    Rewrites of the live config are therefore rate-limited: the newest wanted content is kept
    and written once ``MIN_REWRITE_S`` has passed.  Callers always pass the *current* desired
    state (the Governor loop does so every second), so a newer state replaces an older pending
    one and a stale pending config is never flushed on its own.
    """

    MIN_REWRITE_S = 5.0

    def __init__(self, config_dir: Path, clock=None) -> None:
        import time as _time
        self.config_dir = Path(config_dir)
        self.clock = clock or _time.monotonic
        self._last_write = -1e9
        self.pending: Optional[str] = None

    def _write_config(self, text: str) -> bool:
        path = active_config_path(self.config_dir)
        try:
            if path.read_text(encoding="utf-8") == text:
                self.pending = None
                return False
        except OSError:
            pass
        now = self.clock()
        if path.exists() and now - self._last_write < self.MIN_REWRITE_S:
            self.pending = text  # applied by a later call
            return False
        _atomic(path, text)
        self._last_write = now
        self.pending = None
        return True

    def activate(self, preset: str, position: str, generated_fps: bool = False) -> Path:
        self._write_config(mangohud_config(preset, position, status_path(self.config_dir), generated_fps))
        return active_config_path(self.config_dir)

    def deactivate(self) -> None:
        """Hide the HUD but keep its config: the launch wrapper loads MangoHud
        whenever the config exists, and MangoHud re-reads it, so turning the
        HUD on later works in a running game."""
        self._write_config(HIDDEN_CONFIG)

    def config_exists(self) -> bool:
        return active_config_path(self.config_dir).is_file()

    def remove(self) -> None:
        """No config at all: new launches do not load MangoHud."""
        self.pending = None  # a rate-limited older state must never be published afterwards
        try:
            active_config_path(self.config_dir).unlink()
        except FileNotFoundError:
            pass

    def write_status(self, status: Dict[str, Any], preset: str = "standard") -> bool:
        return _atomic(status_path(self.config_dir), status_line(status, preset) + "\n")
