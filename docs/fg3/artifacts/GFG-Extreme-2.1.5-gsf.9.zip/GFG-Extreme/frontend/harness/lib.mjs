import { build } from "esbuild";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { chromium } = require("playwright");
export const launch = () => chromium.launch({ args: ["--no-sandbox"], ...(process.env.GFG_CHROMIUM ? { executablePath: process.env.GFG_CHROMIUM } : {}) });
const out = await build({ entryPoints: [fileURLToPath(new URL("../src/app.js", import.meta.url))], bundle: true, format: "iife", globalName: "GFGPlugin", write: false, target: "es2020" });
const rb = await build({ entryPoints: [fileURLToPath(new URL("./reactbundle.js", import.meta.url))], bundle: true, format: "iife", write: false, define: {"process.env.NODE_ENV":"\"development\""} });
const reactJs = rb.outputFiles[0].text; const domJs = "";
const dev = (mode, target) => ({ mode, target, reason: { oled: "Steam Deck OLED panel runs 90 Hz", lcd: "Steam Deck LCD panel tops out at 60 Hz", dock: "External display: 60 FPS" }[mode] });
const base = { version: "1.0.0", hud: { enabled: true, preset: "standard", position: "top-left" }, success: true, enabled: false, state: "DISABLED", telemetry: {}, power: {}, limitations: ["a game must be (re)launched after Governor is enabled to use the overlay and diagnostics"], ladder: { attempts: 2, max_attempts: 6 } };
// Real backend shape: {snapshot, summary}.
const tel = (real, out, m) => ({ snapshot: { available: true }, summary: { real: { median: real }, output: { median: out }, latest: { effective_multiplier: m }, frametime: { p95_ms: 24.5, p99_ms: 31.2, stutter_ratio: 0.01 } } });
const xb = (over = {}) => ["upscale", "quiet", "split", "cooling", "act", "memory", "latency", "shield", "instant"].map((id) => ({ id, ...({
  upscale: { state: "active", reason: "render-scale-confirmed", render_pct: 80, sharpness: 0.3 },
  quiet: { state: "unavailable", reason: "no-supported-steam-job-api" }, split: { state: "active", reason: "gpu-bound-cpu-capped", cap_khz: 2400000 },
  cooling: { state: "unavailable", reason: "no-verified-fan-api" }, act: { state: "waiting", reason: "waits-for-settled-watts" },
  memory: { state: "unavailable", reason: "global-memory-tweaks-not-applied" }, latency: { state: "unavailable", reason: "latency-not-measured-on-hardware" },
  shield: { state: "unavailable", reason: "not-validated-on-hardware" }, instant: { state: "active", reason: "remembered-point-verified-again" } }[id]), ...(over[id] || {}) }));
const xstate = (over = {}) => ({ enabled: true, state: "ACTIVE", ceiling: { ceiling_w: 15, source: "stock-limit", user_w: 20 }, tdp_w: 15,
  requested: { render_pct: 80, sharpness: 0.3 }, applied: { render_pct: 80, sharpness: 0.3, sharpness_confirmed: true, source: [1024, 640], output: [1280, 800] },
  sharpness_offset: 0, act_consent: true, boosters: xb(over.boosters), gain: { kind: "unavailable", percent: null, reason: "aba-proof-not-in-this-version" }, ...over, ...(over.boosters ? { boosters: xb(over.boosters) } : {}) });
const xhome = (extreme) => ({ ...base, enabled: true, state: "LOCKED", mode: "extreme", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(54, 90, 1.67), active_point: { multiplier: 1.67, render_scale_pct: 80 }, active_point_mode: "applied", power: { owned: true, observed_tdp_w: extreme.tdp_w, initial_tdp_w: 20 }, effort: { level: "hard" }, battery: { minutes_left: 104 }, budget: { phase: "locked", point: "54x1.67@80", tdp_w: extreme.tdp_w, tdp_control: true, tier: "heavy", flavor: "extreme", scale_capable: true, limits_w: { min: 6, normal: extreme.tdp_w, emergency: extreme.tdp_w } }, extreme });
export const STATES = {
  "home-extreme": xhome(xstate()),
  "home-extreme-verify": xhome(xstate({ state: "VERIFY", applied: { render_pct: 100 }, requested: { render_pct: 90, sharpness: 0.15 }, boosters: { upscale: { state: "waiting", reason: "awaiting-renderer-acknowledgement", render_pct: 90 } } })),
  "home-extreme-restart": xhome(xstate({ tdp_w: 12, ceiling: { ceiling_w: 12, source: "your-limit", user_w: 12 }, applied: { render_pct: 100 }, requested: { render_pct: 100 }, boosters: { upscale: { state: "restart_required", reason: "scaler-not-provisioned-at-launch" }, act: { state: "restart_required", reason: "pacer-not-loaded-at-launch" } } })),
  "home-scale-ignored": { ...base, enabled: true, state: "LOCKED", mode: "budget", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, scale_blocked: "game-ignores-render-scale", budget: { phase: "locked", point: "30x3", tdp_w: 11, tdp_control: true, tier: "ideal", scale_capable: false, limits_w: { min: 6, normal: 15, emergency: 15 } } },
  "home-extreme-consent": { ...base, enabled: true, state: "LOCKED", mode: "balanced", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(45, 90, 2), active_point: { multiplier: 2, render_scale_pct: 100 }, extreme: { enabled: false, state: "OFF" } },
  "home-extreme-offer": { ...base, enabled: true, state: "LOCKED", mode: "balanced", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, power: { owned: true, observed_tdp_w: 11 }, budget: { phase: "locked", point: "30x3", tdp_w: 11, tdp_control: true, tier: "ideal", flavor: "balanced", limits_w: { min: 6, normal: 15, emergency: 15 } }, extreme: { enabled: false, state: "OFF" }, extreme_offer: { headroom_w: 4, ceiling_w: 15, tdp_w: 11, real_target: 30 } },
  // Synthetic sample readings for README screenshots of the actual 2.0.0 UI.
  // No claimed battery gain or unique-frame delivery, no real Steam Deck measurement.
  "home-autopilot": {
    ...base, version: "2.1.0", enabled: true, state: "LOCKED", mode: "autopilot",
    device: dev("oled", 90), target_output_fps: 90,
    telemetry: tel(30, 90, 3),
    active_point: { multiplier: 3, render_scale_pct: 100, base_target_fps: 30 },
    active_point_mode: "applied",
    power: { owned: true, observed_tdp_w: 10, initial_tdp_w: 15, draw_w: 10.3 },
    effort: { level: "medium", reason: "stable real-frame cadence" },
    battery: { minutes_left: 130, percent: 72 },
    sensors: { temp_c: 68, gpu_clock_mhz: 1240, gpu_busy_pct: 99, cpu_top_core_pct: 64 },
    diagnosis: { bottleneck: "gpu", smoothness: "smooth", thermal: "ok" },
    budget: { phase: "locked", point: "30x3", tdp_w: 10, tdp_control: true, tier: "ideal", limits_w: { min: 6, normal: 15, emergency: 15 } },
    autopilot: {
      enabled: true, active: true, state: "HOLD", action: "HOLD",
      reason: "already-efficient", tool: "none",
      message: "Working configuration confirmed.",
      real_fps: 30, output_fps: 90, target_fps: 90,
      preference: "auto",
      gpu_clock: { available: true, level: "auto", current_limit_mhz: 1240 },
      half_rate_shading: { available: true, mode: "1x1", enabled: false },
    },
    autopilot_shading_allowed: true,
    frame_fusion: { setting_enabled: true, enabled: true, state: "observed", processing_path: "native-input", path_observed: true, gain_measured: false },
    frame_os: { mode: "act", enabled: true, act_unlocked: true, feature_settings: { latency: true, shield: true, boost: true, touch_boost: true } },
    autopilot_shading: { available: true, mode: "1x1" },
  },
  "home-autopilot-wait": {
    ...base, version: "2.1.0", enabled: true, state: "LOCKED", mode: "autopilot",
    device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3),
    active_point: { multiplier: 3, render_scale_pct: 100 },
    active_point_mode: "applied",
    power: { owned: true, observed_tdp_w: 11, initial_tdp_w: 15 },
    effort: { level: "medium" },
    autopilot: {
      enabled: true, active: true, state: "HOLD", action: "HOLD",
      reason: "baseline-overlaps-transition", tool: "none",
      message: "Awaiting confirmed game measurements. No GPU or shading change was applied.",
      real_fps: 30, output_fps: 90, target_fps: 90, preference: "smoothness",
      gpu_clock: { available: false },
    },
    autopilot_shading_allowed: true,
    autopilot_shading: { available: true, mode: "1x1", enabled: false },
  },
  "home-idle-oled": { ...base, device: dev("oled", 90), target_output_fps: 90 },
  "home-measuring": { ...base, enabled: true, state: "PROBE", device: dev("oled", 90), target_output_fps: 90, capability: {} },
  get "home-frame-os-learned"() { const s = JSON.parse(JSON.stringify(this["home-frame-os-act"])); Object.assign(s.frame_os.decision, { level: "calm", real_hz: 30 }); s.frame_os.benefit.frames_pct = 1; s.frame_os.game = { sessions: 6, verdicts: { response: "helps", frames: "useless", energy: "unclear" }, disabled: { boost: true, shaping: false, rest: false }, response: { n: 12 }, frames: { n: 5 }, energy: { n: 0 } }; return s; },
  "home-frame-os-act": { ...base, enabled: true, state: "LOCKED", reason: "frame-os-act-holds-point", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(45, 90, 2), active_point: { multiplier: 3, render_scale_pct: 100 }, power: { owned: true, observed_tdp_w: 15 }, effort: { level: "medium" }, battery: { minutes_left: 118 }, frame_os: { mode: "act", enabled: true, acting: true, act_unlocked: true, layer_installed: true, decision: { level: "boost", real_hz: 45 }, telemetry: { live: true, freshness_ms: 13.2, frames: 9000 }, benefit: { ready: true, estimate: false, response_pct: 47, frames_pct: 50, energy_pct: 9, measured: { response: true, frames: true, energy: false } }, ab: true, proof: { enabled: true, response: { n: 5, mean: 47, low: 39, high: 55, measured: true }, frames: { n: 3, mean: 50, low: 44, high: 56, measured: true }, energy: { n: 1, mean: 12, measured: false } }, game: { sessions: 4, verdicts: { response: "helps", frames: "helps", energy: "unclear" }, disabled: { boost: false, shaping: false, rest: false }, response: { n: 9 }, frames: { n: 5 }, energy: { n: 1 } } } },
  "home-frame-os-rest": { ...base, enabled: true, state: "LOCKED", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, power: { owned: true, observed_tdp_w: 11 }, frame_os: { mode: "act", enabled: true, acting: true, act_unlocked: true, layer_installed: true, decision: { level: "rest", real_hz: 30 }, telemetry: { live: true }, benefit: { ready: true, estimate: false, response_pct: 45, frames_pct: 3, energy_pct: -6 } } },
  "home-frame-os-observe": { ...base, enabled: true, state: "LOCKED", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, power: { owned: true, observed_tdp_w: 11 }, frame_os: { mode: "observe", enabled: true, acting: false, layer_installed: true, decision: { level: "calm", real_hz: 30 }, telemetry: { live: true }, benefit: { ready: true, estimate: true, response_pct: 44, frames_pct: 50, energy_pct: 11 } } },
  "home-frame-os-early": { ...base, enabled: true, state: "LOCKED", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, frame_os: { mode: "act", enabled: true, acting: true, act_unlocked: true, decision: { level: "calm", real_hz: 30 }, telemetry: { live: true }, benefit: { ready: false, estimate: false, response_pct: null, frames_pct: null, energy_pct: null } } },
  "home-locked-oled": { ...base, enabled: true, state: "LOCKED", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(45, 90, 2), active_point: { multiplier: 2, render_scale_pct: 100 }, active_point_mode: "applied", power: { owned: true, observed_tdp_w: 9, saved_w: 15 }, effort: { level: "medium" }, battery: { minutes_left: 125 } },
  "home-budget-oled": { ...base, enabled: true, state: "LOCKED", mode: "budget", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, active_point_mode: "applied", power: { owned: true, observed_tdp_w: 9, saved_w: 15 }, effort: { level: "easy" }, budget: { phase: "locked", point: "30x3", tdp_w: 9, tdp_control: true, tier: "ideal", probe: null, limits_w: { min: 6, normal: 15, emergency: 15 } } },
  "home-power-split": { ...base, enabled: true, state: "LOCKED", mode: "budget", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, active_point_mode: "applied", power: { owned: true, observed_tdp_w: 8, saved_w: 15 }, effort: { level: "easy" }, budget: { phase: "locked", point: "30x3", tdp_w: 8, tdp_control: true, tier: "ideal", probe: null, limits_w: { min: 6, normal: 15, emergency: 15 } }, power_split: { available: true, setting: true, enabled: true, phase: "hold", reason: "held", level: 2, cap_khz: 2400000, max_khz: 3500000, ab: null, gain_pct: 7.4, gain_low: 4.1, gain_high: 10.7, pairs: 6, session_pairs: 2, measured: true, draw_pct: 0.4, mhz_pct: 7.9, control: { owned: true, external_change: false }, game_off: false } },
  "home-power-split-short": { ...base, enabled: true, state: "LOCKED", mode: "budget", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, budget: { phase: "locked", point: "30x3", tdp_w: 9, tdp_control: true, tier: "ideal", limits_w: { min: 6, normal: 15, emergency: 15 } }, power_split: { available: true, setting: true, phase: "free", reason: "real-frames-short", level: 0, cap_khz: null, pairs: 0, measured: false, control: { owned: false, external_change: false }, game_off: false } },
  "home-warm-start": { ...base, enabled: true, state: "LOCKED", mode: "budget", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, power: { owned: true, observed_tdp_w: 8, saved_w: 15 }, effort: { level: "easy" }, budget: { phase: "locked", point: "30x3", tdp_w: 8, tdp_control: true, tier: "ideal", probe: null, warm_started: true, limits_w: { min: 6, normal: 15, emergency: 15 } } },
  "home-balanced": { ...base, enabled: true, state: "LOCKED", mode: "balanced", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(45, 90, 2), active_point: { multiplier: 2, render_scale_pct: 100 }, power: { owned: true, observed_tdp_w: 12, saved_w: 15 }, effort: { level: "medium" }, budget: { phase: "locked", point: "45x2", tdp_w: 12, tdp_control: true, tier: "heavy", probe: null, flavor: "balanced", limits_w: { min: 6, normal: 15, emergency: 15 } } },
  "log-saved": { ...base, __log: { recording: false, last_file: "/home/deck/Desktop/GFG-Extreme-log-1.zip", findings: ["No renderer diagnostics were written during the recording: the game was not started with the GFG launch command.", "Median output FPS 90 against a 90 FPS target."] } },
  "setup-bad": { ...base, __setup: { success: true, total: 3, failed: 2, checks: [{ check: "launch wrapper installed", ok: true }, { check: "host MangoHud Vulkan layer present", ok: false, detail: "/usr/share/vulkan/implicit_layer.d/MangoHud.json", advice: "MangoHud's Vulkan layer is not installed on this system, so the in-game overlay cannot appear." }, { check: "overlay config published (active.conf)", ok: false, detail: "/x/hud/active.conf", advice: "Turn the overlay on in Settings → In-game overlay." }] } },
  "home-paused-setup": { ...base, enabled: true, state: "PAUSED", reason: "diagnostics-active-no-events", device: dev("oled", 90), __setup: { success: true, total: 2, failed: 1, checks: [{ check: "renderer diagnostics log: present-diagnostics.log", ok: false, detail: "missing", advice: "Start the game with the GFG launch command (Settings → Launch command), then press RUN." }, { check: "launch wrapper installed", ok: true }] } },
  "readme-home": { ...base, enabled: true, state: "LOCKED", mode: "budget", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, active_point_mode: "applied", power: { owned: true, observed_tdp_w: 9, saved_w: 15 }, effort: { level: "easy" }, battery: { minutes_left: 152 }, sensors: { temp_c: 68, temp_slope_c_per_min: 0.4, gpu_busy_pct: 94, cpu_top_core_pct: 61, battery_discharge_w: 12.8, fan_rpm: 3100 }, diagnosis: { bottleneck: "gpu", thermal: "ok", smoothness: "smooth" }, budget: { phase: "locked", point: "30x3", tdp_w: 9, tdp_control: true, tier: "ideal", probe: null, warm_started: true, limits_w: { min: 6, normal: 15, emergency: 15 } } },
  "budget-memory": { ...base, enabled: true, state: "LOCKED", mode: "budget", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, power: { owned: true, observed_tdp_w: 10, saved_w: 15 }, effort: { level: "easy" }, budget: { phase: "locked", point: "30x3", tdp_w: 10, tdp_control: true, tier: "ideal", probe: null, verifying: "30x3", current_max_multiplier: 3, known_failures: { "33x2.75": 10 }, limits_w: { min: 6, normal: 15, emergency: 15 } } },
  "home-loading": { ...base, enabled: true, state: "PAUSED", reason: "diagnostics-events-no-fps-samples", device: dev("oled", 90) },
  "home-testing": { ...base, enabled: true, state: "APPLY", reason: "awaiting-fresh-evidence", device: dev("oled", 90), request: { point: "33x2.75" } },
  "home-last-session": { ...base, last_session: { minutes: 42.3, avg_output_fps: 89.6, avg_real_fps: 30.2, avg_tdp_w: 10.6, avg_draw_w: 10.1, reference_w: 15, saved_w: 4.4, max_temp_c: 83, hot_pct: 12, stutter_pct: 3, profile: "mako" } },
  "frame-os-no-layer": { ...base, enabled: false, state: "DISABLED", device: dev("oled", 90), frame_os: { mode: "observe", layer_installed: false, layer_error: "this build does not include the Frame OS layer", enabled: false } },
  "home-effort-reason": { ...base, enabled: true, state: "LOCKED", mode: "quality", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, effort: { level: "hard", reason: "x3 required" } },
  "frame-os-refused": { ...base, device: dev("oled", 90), target_output_fps: 90, frame_os: { mode: "off" }, __frameOsFail: true },
  "fusion-prepared": { ...base, mode: "autopilot", frame_fusion: { enabled: true, state: "prepared", path_observed: false } },
  "temporal-shadow": { ...base, temporal_engine: { requested_mode: "off", running_mode: "shadow", restart_required: true, scheduler: { cap_ms: 2, level: 1, force_light: 0 }, state: "shadow-measuring", applied: true, shares: { reuse: 0.3, light: 0.3, full: 0.4 }, gpu_ms: { pair_p50: 2.4, pair_p95: 3.1 }, outputs_dispatched: 200, outputs_gpu_completed: 198, dropped: 4 } },
  "temporal-fallback": { ...base, temporal_engine: { requested_mode: "experimental", state: "fallback", applied: false, fallback_reasons: ["no-external-semaphore-fd"] } },
  "temporal-lmc": { ...base, temporal_engine: { requested_mode: "experimental", state: "generating", algorithm: "lmc", lmc_tier: 1, lmc: { budget: 0.25, cpu_fit_ms: 3.5, first_ready_ms: 14.2, pair_with_fit_ms: 16, deadline_misses: 8 }, gpu_ms: { pair_p50: 8, pair_p95: 11 }, scheduler: { cap_ms: 2 }, outputs_dispatched: 100, outputs_gpu_completed: 98 } },
  "fusion-observed": { ...base, mode: "autopilot", frame_fusion: { enabled: true, state: "observed", path_observed: true, gain_measured: false } },
  "fusion-restart": { ...base, mode: "autopilot", frame_fusion: { enabled: false, state: "restart-required", path_observed: true } },
  "fusion-unsupported": { ...base, mode: "autopilot", frame_fusion: { enabled: true, state: "renderer-unsupported", path_observed: false } },
  "home-paused-external-tdp": { ...base, enabled: true, state: "PAUSED", reason: "external-tdp-change", mode: "balanced", device: dev("oled", 90), target_output_fps: 90 },
  "home-no-model-game": { ...base, device: dev("oled", 90), target_output_fps: 90, __modelTarget: null },
  "home-last-session-above-limit": { ...base, last_session: { minutes: 20, avg_output_fps: 88, avg_real_fps: 44, avg_tdp_w: 17.1, avg_draw_w: 16.4, reference_w: 15, saved_w: -2.1, saved_wh: -0.7, profile: "mako" } },
  "home-last-session-mixed": { ...base, last_session: { minutes: 31, mode: "mixed", modes: { budget: 18, balanced: 13 }, avg_output_fps: 89.6, avg_real_fps: 36, avg_tdp_w: 10.6, reference_w: 15, avg_draw_w: 10.1, saved_w: 4.4, saved_wh: 2.3, battery_minutes_gained: 14, frame_os: { calm: 20, boost: 6, rest: 4 }, frame_os_benefit: { response: 41, frames: 12, energy: 9, estimate: false }, profile: "mako" }, session_history: [{ minutes: 31, mode: "mixed", modes: { budget: 18, balanced: 13 }, avg_output_fps: 89.6, avg_tdp_w: 10.6 }] },
  "home-cooling": { ...base, enabled: true, state: "LOCKED", mode: "budget", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, diagnosis: { thermal: "hot" }, sensors: { temp_c: 84 }, budget: { phase: "locked", point: "30x3", tdp_w: 8, tdp_control: true, tier: "ideal", thermal: "hot", thermal_deferred: true, heat_limited: true, limits_w: { min: 6, normal: 15, emergency: 15 } } },
  "home-history": { ...base, session_history: [{ minutes: 29, mode: "budget", avg_output_fps: 89.6, avg_tdp_w: 10.7, max_temp_c: 77 }, { minutes: 12, mode: "quality", avg_output_fps: 88.1, avg_tdp_w: 19.4 }] },
  "home-saving": { ...base, enabled: true, state: "LOCKED", mode: "budget", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, power: { owned: true, observed_tdp_w: 9, ceiling_tdp_w: 15, initial_tdp_w: 15 }, session: { minutes: 3 }, budget: { phase: "locked", point: "30x3", tdp_w: 9, tdp_control: true, tier: "ideal", limits_w: { min: 6, normal: 15, emergency: 15 } } },
  "home-cap-ignored": { ...base, enabled: true, state: "LOCKED", mode: "budget", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(30, 90, 3), active_point: { multiplier: 3, render_scale_pct: 100 }, power: { owned: true, observed_tdp_w: 8 }, power_feedback: { draw_w: 17.4, cap_w: 8, cap_ignored: true }, budget: { phase: "locked", point: "30x3", tdp_w: 8, tdp_control: true, tier: "ideal", cap_ignored: true, limits_w: { min: 6, normal: 15, emergency: 15 } } },
  "home-quality-oled": { ...base, enabled: true, state: "LOCKED", mode: "quality", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(45, 90, 2), active_point: { multiplier: 2, render_scale_pct: 100 }, active_point_mode: "applied", power: { owned: true, observed_tdp_w: 12, saved_w: 15 }, effort: { level: "medium" } },
  "home-locked-lcd": { ...base, enabled: true, state: "OPTIMIZE_POWER", device: dev("lcd", 60), target_output_fps: 60, telemetry: tel(30, 60, 2), active_point: { multiplier: 2, render_scale_pct: 100 }, power: { owned: true, observed_tdp_w: 8, saved_w: 15 }, effort: { level: null, assessing: true } },
  "home-paused-relaunch": { ...base, enabled: true, state: "PAUSED", reason: "relaunch-required-for-governor-overlay", device: dev("oled", 90), target_output_fps: 90, capability: { reason: "relaunch-required-for-governor-overlay" } },
  "home-no-tdp": { ...base, enabled: true, state: "OBSERVE_ONLY", reason: "tdp-control-not-writable", device: dev("oled", 90), target_output_fps: 90, telemetry: tel(45, 90, 2), active_point: { multiplier: 2, render_scale_pct: 100 } },
  "home-relaunch-dock": { ...base, enabled: true, state: "PLAN", device: dev("dock", 60), target_output_fps: 60, capability: { reason: "relaunch-required-for-governor-overlay" } },
};
const mockSrc = (state, extra) => `
window.SP_REACT = React; window.DFL = { staticClasses: { Title: "t" }, Focusable: null, TextField: (p) => React.createElement("input", { ...p, "data-tf": "1" }) };
window.__patches = [];
window.SteamClient = { Apps: { AddShortcut: async (n, exe, dir, opts) => { window.__addShortcut = [n, exe, dir, opts]; window.__adds = (window.__adds || 0) + 1; window.__addedShortcut = 3000000001; return 3000000001; }, SetShortcutName() {}, SetShortcutExe() {}, SetShortcutStartDir() {},
  RunGame: (id, a, b, c) => { (window.__runGame = window.__runGame || []).push(id); }, RemoveShortcut: (id) => { window.__removed = id; } } };
window.appStore = { GetAppOverviewByAppID: (id) => (id === 292030 ? { display_name: "Sample Game" } : id && id === window.__addedShortcut ? { display_name: "GFG Shell", m_gameid: ((BigInt(id) << 32n) | 0x02000000n).toString() } : null) };
window.__state = ${JSON.stringify(state)};
window.__cfg = ${JSON.stringify(extra.cfg || { fg_backend: "gfg", multiplier: 2, })};
var callable = (n) => async (...a) => ({ get_governor_status: () => window.__state, get_profiles: () => ({ profiles: ["Default", "Sample Game", "Another Game"], current_profile: "Sample Game" }),
  get_profile_config: () => ({ config: window.__cfg }), get_pipeline_inspector: () => ({ saved: { fg_backend: "gfg", multiplier: 2, scaling: "off" }, effective: { fg_backend: "gfg", multiplier: 2, scaling: "off" }, actual: { renderer: "loaded", multiplier: 2, ...(window.__state.__actual || {}) } }),
  get_shell_status: () => ({ success: true, packaged: true, packaged_version: "0.1.0", installed: !!window.__shellInstalled, installed_version: window.__shellInstalled ? "0.1.0" : "", update_available: false, path: "/home/deck/.local/share/gfg-shell/app/gfg-shell.sh", start_dir: "/home/deck/.local/share/gfg-shell/app", shortcut_appid: window.__shellShortcut || null, progress: { busy: false } }),
  install_gfg_shell: () => { window.__shellInstalls = (window.__shellInstalls || 0) + 1; if (window.__state.__shellFail) return { success: false, error: "Godot download failed its SHA-256 check" }; window.__shellInstalled = true; return { success: true, version: "0.1.0" }; },
  set_shell_shortcut: (id) => { window.__shellShortcut = id; return { success: true }; },
  uninstall_gfg_shell: () => { window.__shellInstalled = false; return { success: true }; },
  check_mako_installed: () => ({ installed: true, installed_engine_version: '4.0.1', expected_engine_version: '4.0.1', engine_update_required: false, host_architecture_supported: true }), check_flatpak_extension_status: () => ({ success: true, installed_23_08: false, installed_24_08: true, installed_25_08: true }), get_flatpak_apps: () => ({ success: true, total_apps: 2, apps: [{ app_id: 'org.example.A', app_name: 'Heroic', has_filesystem_override: true, has_wrapper_override: true, has_required_env_override: true }, { app_id: 'org.example.B', app_name: 'Lutris', has_filesystem_override: false, has_wrapper_override: false }] }),
  get_config_schema: () => ({ field_names: ['scaling_enabled','scaling_factor','multiplier','dll','allow_fp16'], field_types: { scaling_enabled: 'boolean', scaling_factor: 'float', multiplier: 'integer', dll: 'string', allow_fp16: 'boolean' }, defaults: { scaling_enabled: false, scaling_factor: 1.5, multiplier: 2, dll: '', allow_fp16: true }, descriptions: { scaling_enabled: 'restart-bound scaling engine switch', scaling_factor: 'output scaling factor from 1.0x to 2.0x', multiplier: 'fixed multiplier', dll: 'optional full path to Lossless.dll', allow_fp16: 'allow FP16 acceleration' } }),
  run_setup_check: () => window.__state.__setup || ({ success: true, total: 3, failed: 0, checks: [{ check: 'launch wrapper installed', ok: true }, { check: 'overlay config published (active.conf)', ok: true }, { check: 'TDP control: fastPPT/slowPPT cap writable', ok: true }] }),
  get_log_recording_status: () => window.__state.__log || {},
  get_launch_option: () => ({ launch_option: "/home/deck/.local/bin/gfg %command%" }),
  get_governor_game_model_target: (p) => ({ success: true, target: window.__state.__modelTarget !== undefined ? window.__state.__modelTarget : { profile: p, app_id: "292030", game: "app:292030" } }),
  set_governor_power_split: (enabled) => { (window.__splitSets = window.__splitSets || []).push(enabled); return { success: true, power_split: !!enabled }; },
  set_governor_auto_flow: (enabled) => { (window.__flowSets = window.__flowSets || []).push(enabled); if (window.__state.__flowFail) return { success: false, error: "Could not save flow policy" }; return { success: true, enabled }; },
  set_governor_mode: (p, m) => { (window.__modes = window.__modes || []).push(m); return { success: true, mode: m }; },
  set_governor_extreme_act_consent: (allow) => { (window.__consents = window.__consents || []).push(allow); return { success: true, consent: !!allow }; },
  set_governor_extreme_sharpness: (p, v) => { (window.__sharp = window.__sharp || []).push(v); return { success: true, offset: v }; },
  set_governor_frame_os_feature: (p, feature, enabled) => {
    (window.__featureSets = window.__featureSets || []).push([p, feature, enabled]);
    if (window.__state.__featureFail) return { success: false, error: "Could not save frame timing" };
    const features = { latency: true, shield: true, touch_boost: true, boost: true, ...(window.__state.extreme || {}).feature_settings, [feature]: enabled };
    window.__state.extreme = { ...(window.__state.extreme || {}), feature_settings: features };
    window.__state.frame_os = { ...(window.__state.frame_os || {}), feature_settings: features };
    return { success: true, features };
  },
  set_governor_frame_os_ab: (enabled) => { (window.__abSets = window.__abSets || []).push(enabled); return { success: true, ab: !!enabled }; },
  set_native_gsf: (mode) => { (window.__nativeGsfSets = window.__nativeGsfSets || []).push(mode); return window.__state.__nativeInstallFail ? { success: false, error: "native-launcher-not-ready-after-install" } : { success: true, mode, relaunch_required: true }; },
  set_governor_temporal_engine: (mode, consent) => { (window.__teSets = window.__teSets || []).push([mode, consent]); return mode === "experimental" && !consent ? { success: false, error: "consent-required" } : { success: true, mode, relaunch_required: true }; },
  set_governor_frame_fusion: (enabled) => { (window.__fusionSets = window.__fusionSets || []).push(enabled); return window.__state.__fusionFail ? { success: false, error: "Could not save Frame Fusion" } : { success: true, enabled }; },
  set_governor_frame_os_act_unlock: (enabled) => { (window.__actUnlocks = window.__actUnlocks || []).push(enabled); return { success: true, act_unlocked: !!enabled }; },
  set_governor_frame_os: (p, m) => (window.__state.__frameOsFail ? { success: false, error: "marker: read-only" } : { success: true, mode: m }),
  forget_governor_game_model: (p) => { (window.__forgets = window.__forgets || []).push(p); return { success: true, forgotten: 2, game: "app:292030" }; },
  update_profile_config_fields: (p, c) => { window.__patches.push(c); Object.assign(window.__cfg, c); return { success: true }; } }[n] || (() => ({ success: true })))(...a);
var definePlugin = (f) => f;`;

export async function openPage(browser, state, nav = [], extra = {}) {
  const page = await browser.newPage({ viewport: { width: 330, height: 760 }, deviceScaleFactor: 2 });
  const errors = [];
  page.on("pageerror", (e) => errors.push(String(e)));
  const code = out.outputFiles[0].text.replace(/^var GFGPlugin = /, "window.__P = ");
  await page.setContent(`<html><body style="margin:0;background:#0a0a0c"><div id=r></div></body></html>`);
  await page.addScriptTag({ content: reactJs });
  await page.addScriptTag({ content: mockSrc(state, extra) + "\n" + code });
  await page.evaluate(() => { const p = window.__P.default(); window.__createRoot(document.getElementById("r")).render(p.content); });
  await page.waitForTimeout(400);
  for (const t of nav) { await page.getByText(t, { exact: true }).first().click(); await page.waitForTimeout(250); }
  page.__errors = errors;
  return page;
}
