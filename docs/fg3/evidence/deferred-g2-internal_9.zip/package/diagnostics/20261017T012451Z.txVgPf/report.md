# GFG Native diagnostic report — NOT ACCEPTANCE

This report summarizes application/WSI instrumentation only. It does not prove physical OLED scanout.

- Generator bridge initialized in captured log: **yes**
- Algorithm: **gsf**
- Launched command exit code (may be a Steam wrapper): **0**
- Physical display / KMS scanout: **unobserved**
- 30 real → 90 distinct physical FPS acceptance: **false / not established**
- Synthetic WSI handoffs observed: **yes**

## Latest captured cumulative counters

Latest process snapshot across swapchain recreations; earlier snapshots are not added again.

- real presents: 6
- synthetic presents: 8
- skipped outputs: 2
- errors: 0
- host pixel reads on present path: 0
- CPU waits on present path: 0
- API handoffs per real present: 2.333× (not displayed FPS)
- Synthetic output opportunities handed to WSI: 80.00%

Backpressure event counts (events, not lost output counts):

- TE busy: 0
- ring busy: 0
- image acquire not ready: 0
- history holds including initialization: 2

## Latest bridge output losses

This bridge saw 6 real presents. These counts are per bridge, not process totals.

- ring unavailable: 0
- TE unavailable: 0
- history restart after a gap: 2
- image unavailable: 0
- metadata/disabled bypass: 0
- error recovery: 0
- Reservations rescued by selecting another free slot: 0

## Output worker CPU call time

- Samples: 4
- Full present call median / p95: 334834.5 / 343328.7 µs
- Layer-owned CPU median / p95: 28973.1 / 58658.6 µs
- These are output-thread call timings, including its resource polling and downstream WSI. They are not the game's API-call time or display latency.

## Game present-call enqueue/backpressure time

- Samples: 4; median / p95 / max: 130.7 / 130.7 / 317.3 µs
- Includes waiting for a bounded mailbox slot; excludes GPU completion and physical scanout.

## Bounded output worker

- Submitted / finished jobs: 6 / 6
- Stale jobs reset to real-only history: 1
- Mailbox backpressure events: 0; deferred WSI error: 0
- At most one queued and one executing job; unknown metadata drains earlier jobs before synchronous forwarding.

## Latest bridge GPU timestamp samples

- Completed generated-pair samples: 3; held samples excluded: 0
- Analysis start → first output ready, median / p95: 22.570 / 54.885 ms
- Analysis start → second output ready, median / p95: 111.043 / 112.801 ms
- Sampled completed pairs, not an exhaustive trace. Elapsed GPU timestamps include queue/scheduling gaps; game rendering, transport copies and physical scanout are outside this interval.

LMC analysis stage means (overlap with the ready intervals above; do not add twice):

- search_b: 4.555 ms (3 samples)
- search_a: 3.828 ms (3 samples)
- layers: 1.262 ms (3 samples)
- model: 9.698 ms (3 samples)
- field: 1.468 ms (3 samples)
- masked: 0.421 ms (3 samples)
- orphan: 8.535 ms (3 samples)
- field2: 1.661 ms (3 samples)

## Optional Vulkan present-wait observations

- No `present_done` records were captured; completed monitored presents are not established (a monitor may have started without receiving IDs).

## Pair-level measured trace

Source FPS and accepted WSI rates below come from timestamps. No Real × multiplier estimate.
Drop codes: 0 ring; 1 TE busy; 2 history; 3 WSI acquire; 4 bypass; 5 error; 6 deadline; 7 cut; 8 display budget; 9 duplicate.
GPU durations are sampled device timestamps; readiness observations include CPU/queue waits.
```json
{
  "scope": "source/API/WSI observations; no physical scanout or uniqueness proof",
  "pairs": 6,
  "invalid_records": 0,
  "invalid_pairs": [],
  "rates": {
    "source": [
      {
        "pid": 360572,
        "generation": 1,
        "count": 6,
        "fps": 1.8496605904630663
      }
    ],
    "real_wsi": [
      {
        "pid": 360572,
        "generation": 1,
        "count": 6,
        "fps": 2.4843479446279426
      }
    ],
    "generated_wsi": [
      {
        "pid": 360572,
        "generation": 1,
        "count": 8,
        "fps": 6.250464967624324
      }
    ],
    "all_wsi": [
      {
        "pid": 360572,
        "generation": 1,
        "count": 14,
        "fps": 6.459304656032651
      }
    ]
  },
  "drop_codes": {
    "2": 2
  },
  "drop_details": {
    "not-admitted": 2
  },
  "capture_to_worker_ms": {
    "median": 0.54171,
    "p95": 1.158939,
    "max": 1030.546367
  },
  "mailbox_wait_ms": {
    "median": 0.14009749999999999,
    "p95": 0.537985,
    "max": 1.061428
  },
  "capture_to_admission_ms": {
    "median": 0.126803,
    "p95": 0.309266,
    "max": 1030.377737
  },
  "gpu_samples": 3,
  "gpu_first_ready_ms": {
    "median": 22.569839,
    "p95": 22.569839,
    "max": 58.475426
  },
  "gpu_last_ready_ms": {
    "median": 111.043154,
    "p95": 111.043154,
    "max": 112.995958
  },
  "compositor_feedback": 0,
  "physical_displayed_fps": null,
  "unique_displayed_fps": null
}
```

## Device snapshot

```text
schema=1
mode=native
capture_utc=2026-10-17T01:24:51Z
command_basename=wsi-gpu-smoke

--- kernel ---
Linux fe79944db113 6.18.44 #1 SMP Sat Sep 26 20:02:31 UTC 2026 x86_64 GNU/Linux

--- OS release ---
PRETTY_NAME="Debian GNU/Linux 13 (trixie)"
NAME="Debian GNU/Linux"
VERSION_ID="13"
VERSION="13 (trixie)"
VERSION_CODENAME=trixie
DEBIAN_VERSION_FULL=13.6
ID=debian
HOME_URL="https://www.debian.org/"
SUPPORT_URL="https://www.debian.org/support"
BUG_REPORT_URL="https://bugs.debian.org/"

--- installed graphics packages ---
pacman=not-installed

--- selected runtime variables ---
VK_INSTANCE_LAYERS=VK_LAYER_GFG_native:VK_LAYER_KHRONOS_validation
VK_LAYER_PATH=/workspace/gfg-deferred-package-final/home/.local/share/gfg-native:/workspace/.gfg-validation-new/layers
GFG_NATIVE_FG=1
GFG_NATIVE_GPU_BRIDGE=1
GFG_NATIVE_GPU_SYNC=same-device
GFG_NATIVE_ALGO=gsf
GFG_NATIVE_TRACE=1
GFG_NATIVE_TIMING=1
GFG_NATIVE_PRESENT_TRACE=1
GFG_NATIVE_MODE=3
GFG_NATIVE_OUTPUT_HZ=9
GFG_NATIVE_ASYNC=1
GFG_NATIVE_FORCE_FIFO=0

--- installed GFG payload SHA-256 ---
7ddc744f42c5956fb33100977cea2884d8ded2fea2beea2c4597b4ac88771b30  /workspace/gfg-deferred-package-final/home/.local/share/gfg-native/libVkLayer_gfg_native.so
ceb38db538a1603852f9b9f92f64b896bbe969568a602495ca2959cdd39f91df  /workspace/gfg-deferred-package-final/home/.local/share/gfg-native/VkLayer_gfg_native.json
2240deb7e63853693651edd8c4e651bfc18a29bd5f77ddb29ecb1924076ececc  /workspace/gfg-deferred-package-final/home/.local/share/gfg-native/diagnose.sh
2c7d0ddbc647108e97946742ca7e52ddffbaf849fe4f8bb1d042009744e0fa85  /workspace/gfg-deferred-package-final/home/.local/share/gfg-native/accept_report.py

--- memory ---
MemTotal:       34906040 kB
MemAvailable:   33277852 kB

--- DRM device IDs ---

--- power / temperature snapshots (raw sysfs units) ---

--- Vulkan summary (hardware UUID fields removed) ---
vulkaninfo=not-installed
```
