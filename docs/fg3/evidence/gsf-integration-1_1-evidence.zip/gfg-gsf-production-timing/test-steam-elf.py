import os,subprocess,json
from pathlib import Path
out=Path('/workspace/gfg-native-gsf-kt3-final/steam-elf');out.mkdir(exist_ok=True)
base=dict(os.environ,PATH='/workspace/.gfg-sysroot/usr/bin:/usr/bin:/bin',LD_LIBRARY_PATH='/workspace/.gfg-sysroot/usr/lib/x86_64-linux-gnu',VK_ICD_FILENAMES='/workspace/.gfg-sysroot/usr/share/vulkan/icd.d/lvp_icd.json',LP_NUM_THREADS='4',MESA_SHADER_CACHE_DIR='/tmp/gfg-shader-cache',DISPLAY=':93',GFG_NATIVE_FG='1',GFG_NATIVE_GPU_BRIDGE='1',GFG_NATIVE_ASYNC='1',GFG_NATIVE_GPU_SYNC='same-device',GFG_NATIVE_ALGO='gsf',GFG_NATIVE_OUTPUT_HZ='9',GFG_TEST_EXPECT_GPU='1',GFG_TEST_ALLOW_SKIPS='1',GFG_TEST_VALIDATION='1',GFG_TEST_FRAMES='8',GFG_TEST_SOURCE_HZ='3')
results=[]
for mode,order,extra in [('3','VK_LAYER_GFG_native:VK_LAYER_KHRONOS_validation',{}),('2','VK_LAYER_KHRONOS_validation:VK_LAYER_GFG_native',{}),('3','VK_LAYER_GFG_native:VK_LAYER_KHRONOS_validation',{'GFG_TEST_RECREATE':'1'}),('3','VK_LAYER_GFG_native:VK_LAYER_KHRONOS_validation',{'GFG_TEST_UNKNOWN_PRESENT':'1'})]:
    name=f'{mode}-{len(results)}';env=dict(base,**extra,GFG_NATIVE_MODE=mode,VK_INSTANCE_LAYERS=order,VK_LAYER_PATH='/workspace/.gfg-steam-native:/workspace/.gfg-validation-new/layers')
    result=subprocess.run(['/workspace/.gfg-integration-native/wsi-gpu-smoke'],env=env,capture_output=True,text=True,timeout=90)
    log=result.stdout+result.stderr;(out/(name+'.log')).write_text(log)
    passed=result.returncode==0 and 'validation errors=0' in log and 'Validation Error' not in log
    results.append({'name':name,'mode':mode,'order':order,'extra':extra,'passed':passed,'returncode':result.returncode})
    print(name,'PASS' if passed else 'FAIL',flush=True)
(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(0 if all(r['passed'] for r in results) else 1)
