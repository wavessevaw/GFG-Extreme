import json,os,subprocess,importlib.util
from pathlib import Path
root=Path('/workspace/GFG-Extreme-integration')
base=dict(os.environ,PATH='/workspace/.gfg-sysroot/usr/bin:/usr/bin:/bin',LD_LIBRARY_PATH='/workspace/.gfg-sysroot/usr/lib/x86_64-linux-gnu',VK_ICD_FILENAMES='/workspace/.gfg-sysroot/usr/share/vulkan/icd.d/lvp_icd.json',LP_NUM_THREADS='4',MESA_SHADER_CACHE_DIR='/tmp/gfg-shader-cache',DISPLAY=':93',GFG_NATIVE_FG='1',GFG_NATIVE_GPU_BRIDGE='1',GFG_NATIVE_ASYNC='1',GFG_NATIVE_GPU_SYNC='same-device',GFG_NATIVE_ALGO='gsf',GFG_NATIVE_TIMING='1',GFG_TEST_EXPECT_GPU='1',GFG_TEST_ALLOW_SKIPS='1')
spec=importlib.util.spec_from_file_location('report',root/'scripts/accept_report.py');report=importlib.util.module_from_spec(spec);spec.loader.exec_module(report)
for name,hz,source,n,validation in [('after-budget-90',90,30,45,False),('g2-only-budget',9,4,8,True)]:
    out=Path('/workspace/gfg-gsf-production-timing')/name;out.mkdir(exist_ok=True)
    e=dict(base,GFG_NATIVE_OUTPUT_HZ=str(hz),GFG_NATIVE_TELEMETRY=str(out/'pairs.jsonl'),GFG_TEST_FRAMES=str(n),GFG_TEST_SOURCE_HZ=str(source),VK_INSTANCE_LAYERS='VK_LAYER_GFG_native'+(':VK_LAYER_KHRONOS_validation' if validation else ''),VK_LAYER_PATH='/workspace/.gfg-integration-native'+(':/workspace/.gfg-validation-new/layers' if validation else ''))
    if validation:e['GFG_TEST_VALIDATION']='1'
    (out/'pairs.jsonl').unlink(missing_ok=True)
    result=subprocess.run(['/workspace/.gfg-integration-native/wsi-gpu-smoke'],env=e,cwd=root,capture_output=True,text=True,timeout=90)
    (out/'runtime.log').write_text(result.stdout+result.stderr)
    summary=report.summarize_trace((out/'pairs.jsonl').read_text());summary['returncode']=result.returncode
    summary['case']=name;summary['configured_hz']=hz;summary['configured_source_hz']=source
    ps=[json.loads(x) for x in (out/'pairs.jsonl').read_text().splitlines() if '"event":"pair"' in x]
    summary['g1_skipped_g2_accepted']=sum(p['drop_code'][0]!=-1 and p['drop_code'][1]==-1 for p in ps)
    summary['g2_only_dispatches']=sum(p.get('compute_mask')==2 and p.get('dispatched_outputs')==1 for p in ps)
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(name, 'exit', result.returncode, 'G2-only dispatches',summary['g2_only_dispatches'],'G1 skipped/G2 accepted',summary['g1_skipped_g2_accepted'],flush=True)
